export type PageSize = 'a4' | 'a3' | 'letter' | 'legal' | 'fit_image' | 'custom';
export type PageOrientation = 'portrait' | 'landscape' | 'auto';
export type ImageFit = 'contain' | 'cover' | 'original' | 'stretch';
export type MarginsPreset = 'none' | 'small' | 'medium' | 'large' | 'custom';
export type ImageQuality = 'high' | 'medium' | 'low';
export type PageNumberPosition = 'bottom-center' | 'bottom-right' | 'top-right' | 'bottom-left';
export type PageNumberFormat = 'page_of_total' | 'simple' | 'page_only';

export interface UploadedImage {
  id: string;
  name: string;
  size: number;
  type: string;
  src: string;
  width: number;
  height: number;
  rotation: number; // 0, 90, 180, 270
  aspectRatio: number;
}

export interface PdfSettings {
  pageSize: PageSize;
  customWidth: number; // in mm
  customHeight: number; // in mm
  orientation: PageOrientation;
  imageFit: ImageFit;
  margins: MarginsPreset;
  customMargin: number; // in mm
  quality: ImageQuality;
  filename: string;
  pageNumbers: boolean;
  pageNumberPosition: PageNumberPosition;
  pageNumberFormat: PageNumberFormat;
  backgroundColor: string;
  headerText: string;
  footerText: string;
}

export interface PdfGenerationState {
  isGenerating: boolean;
  progress: number;
  currentStepText: string;
  generatedBlob: Blob | null;
  generatedUrl: string | null;
  generatedSize: number;
  generatedPages: number;
  error: string | null;
}

export interface PageDimensionsMm {
  width: number;
  height: number;
}

import React, { useState, useEffect, useRef } from 'react';
import {
  FileText,
  Upload,
  Sparkles,
  Download,
  Trash2,
  Sliders,
  ChevronRight,
  ShieldCheck,
  Zap,
  Layers,
  HelpCircle,
  Plus,
  RefreshCw,
} from 'lucide-react';
import { UploadedImage, PdfSettings, PdfGenerationState } from './types';
import { generatePdf } from './utils/pdfGenerator';
import { getSampleImages } from './utils/sampleImages';
import { Header } from './components/Header';
import { HeroSection } from './components/HeroSection';
import { Dropzone } from './components/Dropzone';
import { ImageManager } from './components/ImageManager';
import { PdfLivePreview } from './components/PdfLivePreview';
import { PdfSettingsPanel } from './components/PdfSettingsPanel';
import { ConversionModal } from './components/ConversionModal';
import { SuccessModal } from './components/SuccessModal';
import { ImagePreviewModal } from './components/ImagePreviewModal';
import { FeaturesSection } from './components/FeaturesSection';
import { HowItWorksSection } from './components/HowItWorksSection';
import { FaqSection } from './components/FaqSection';
import { PrivacyBanner } from './components/PrivacyBanner';
import { Footer } from './components/Footer';

const DEFAULT_SETTINGS: PdfSettings = {
  pageSize: 'a4',
  customWidth: 210,
  customHeight: 297,
  orientation: 'portrait',
  imageFit: 'contain',
  margins: 'small',
  customMargin: 5,
  quality: 'high',
  filename: 'Image2PDF_Document',
  pageNumbers: true,
  pageNumberPosition: 'bottom-center',
  pageNumberFormat: 'page_of_total',
  backgroundColor: '#ffffff',
  headerText: '',
  footerText: '',
};

export default function App() {
  const [images, setImages] = useState<UploadedImage[]>([]);
  const [activePageIndex, setActivePageIndex] = useState<number>(0);
  const [settings, setSettings] = useState<PdfSettings>(DEFAULT_SETTINGS);
  const [darkMode, setDarkMode] = useState<boolean>(() => {
    return window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
  });
  const [previewModalImage, setPreviewModalImage] = useState<UploadedImage | null>(null);
  const [isLoadingDemo, setIsLoadingDemo] = useState<boolean>(false);
  const [generationState, setGenerationState] = useState<PdfGenerationState>({
    isGenerating: false,
    progress: 0,
    currentStepText: '',
    generatedBlob: null,
    generatedUrl: null,
    generatedSize: 0,
    generatedPages: 0,
    error: null,
  });

  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const converterRef = useRef<HTMLDivElement | null>(null);

  // Sync Dark Mode class on <html>
  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [darkMode]);

  // Keyboard navigation & shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Avoid intercepting if user is typing in an input
      if (
        ['INPUT', 'TEXTAREA', 'SELECT'].includes(
          (document.activeElement?.tagName || '').toUpperCase()
        )
      ) {
        return;
      }

      if (images.length > 0) {
        if (e.key === 'ArrowLeft') {
          setActivePageIndex((prev) => Math.max(0, prev - 1));
        } else if (e.key === 'ArrowRight') {
          setActivePageIndex((prev) => Math.min(images.length - 1, prev + 1));
        } else if (e.key.toLowerCase() === 'r') {
          const currentImg = images[activePageIndex];
          if (currentImg) {
            handleRotateImage(currentImg.id, 90);
          }
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [images, activePageIndex]);

  const handleAddImages = (newImages: UploadedImage[]) => {
    setImages((prev) => [...prev, ...newImages]);
    // Scroll smoothly to converter workspace
    setTimeout(() => {
      converterRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, 100);
  };

  const handleReorderImages = (reordered: UploadedImage[]) => {
    setImages(reordered);
    if (activePageIndex >= reordered.length) {
      setActivePageIndex(Math.max(0, reordered.length - 1));
    }
  };

  const handleRotateImage = (id: string, deltaDegrees: number) => {
    setImages((prev) =>
      prev.map((img) => {
        if (img.id === id) {
          const newRot = (img.rotation + deltaDegrees + 360) % 360;
          return { ...img, rotation: newRot };
        }
        return img;
      })
    );
  };

  const handleDeleteImage = (id: string) => {
    setImages((prev) => {
      const filtered = prev.filter((img) => img.id !== id);
      if (activePageIndex >= filtered.length) {
        setActivePageIndex(Math.max(0, filtered.length - 1));
      }
      return filtered;
    });
  };

  const handleClearAll = () => {
    if (images.length === 0) return;
    if (window.confirm('Are you sure you want to remove all uploaded images?')) {
      setImages([]);
      setActivePageIndex(0);
    }
  };

  const handleTryDemo = async () => {
    setIsLoadingDemo(true);
    try {
      const samples = await getSampleImages();
      setImages(samples);
      setActivePageIndex(0);
      setTimeout(() => {
        converterRef.current?.scrollIntoView({ behavior: 'smooth' });
      }, 100);
    } catch (err) {
      console.error('Failed to load sample demo images:', err);
    } finally {
      setIsLoadingDemo(false);
    }
  };

  const handleCreatePdf = async () => {
    if (images.length === 0) return;

    setGenerationState({
      isGenerating: true,
      progress: 5,
      currentStepText: 'Preparing images...',
      generatedBlob: null,
      generatedUrl: null,
      generatedSize: 0,
      generatedPages: 0,
      error: null,
    });

    try {
      const result = await generatePdf(images, settings, (progress, stepText) => {
        setGenerationState((prev) => ({
          ...prev,
          progress,
          currentStepText: stepText,
        }));
      });

      setGenerationState({
        isGenerating: false,
        progress: 100,
        currentStepText: 'Done!',
        generatedBlob: result.blob,
        generatedUrl: result.url,
        generatedSize: result.size,
        generatedPages: result.pageCount,
        error: null,
      });
    } catch (err: any) {
      console.error('PDF Generation Error:', err);
      setGenerationState((prev) => ({
        ...prev,
        isGenerating: false,
        error: err.message || 'Failed to generate PDF. Please try again.',
      }));
    }
  };

  const scrollToSection = (id: string) => {
    if (id === 'hero') {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } else if (id === 'converter') {
      converterRef.current?.scrollIntoView({ behavior: 'smooth' });
    } else {
      const elem = document.getElementById(id);
      elem?.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 transition-colors">
      {/* 1. Header Navigation */}
      <Header
        darkMode={darkMode}
        onToggleDarkMode={() => setDarkMode(!darkMode)}
        onNavigate={scrollToSection}
        imageCount={images.length}
        onStartConverting={() => {
          if (images.length > 0) {
            converterRef.current?.scrollIntoView({ behavior: 'smooth' });
          } else {
            fileInputRef.current?.click();
          }
        }}
      />

      <main className="flex-1">
        {/* 2. Hero Section */}
        <HeroSection
          onTriggerUpload={() => fileInputRef.current?.click()}
          onTryDemo={handleTryDemo}
          isLoadingDemo={isLoadingDemo}
        />

        {/* 3. Converter Workspace Section */}
        <section
          ref={converterRef}
          id="converter"
          className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-16 pt-4"
        >
          {images.length === 0 ? (
            /* Empty State: Large Dropzone Card */
            <div className="max-w-3xl mx-auto">
              <Dropzone onImagesAdded={handleAddImages} inputRef={fileInputRef} />
            </div>
          ) : (
            /* Active 3-Panel Workspace */
            <div className="space-y-4">
              {/* Workspace Header Toolbar */}
              <div className="flex flex-wrap items-center justify-between gap-3 p-4 bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl shadow-sm">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-indigo-50 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-400 flex items-center justify-center font-bold">
                    <FileText className="w-5 h-5" />
                  </div>
                  <div>
                    <h2 className="text-base font-bold text-slate-900 dark:text-white leading-tight">
                      PDF Document Studio
                    </h2>
                    <p className="text-xs text-slate-500 dark:text-slate-400">
                      {images.length} {images.length === 1 ? 'page' : 'pages'} ready • Output: {settings.filename || 'document'}.pdf
                    </p>
                  </div>
                </div>

                {/* Prominent Action Button */}
                <div className="flex items-center gap-2.5">
                  <button
                    id="create-pdf-top-button"
                    onClick={handleCreatePdf}
                    className="px-6 py-2.5 rounded-xl font-bold text-white bg-indigo-600 hover:bg-indigo-500 active:bg-indigo-700 shadow-md shadow-indigo-600/30 hover:shadow-indigo-600/40 hover:-translate-y-0.5 active:translate-y-0 transition-all flex items-center gap-2 text-sm cursor-pointer"
                  >
                    <Download className="w-4 h-4" />
                    <span>Create PDF</span>
                  </button>
                </div>
              </div>

              {/* 3-Section Grid Workspace */}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 items-start">
                {/* Left Panel: Images Thumbnails & Order (3 cols) */}
                <div className="lg:col-span-3 h-full">
                  <ImageManager
                    images={images}
                    activePageIndex={activePageIndex}
                    onSelectPage={setActivePageIndex}
                    onReorderImages={handleReorderImages}
                    onRotateImage={handleRotateImage}
                    onDeleteImage={handleDeleteImage}
                    onClearAll={handleClearAll}
                    onAddImages={handleAddImages}
                    onOpenPreviewModal={setPreviewModalImage}
                  />
                </div>

                {/* Center Panel: Live PDF Preview Canvas (6 cols) */}
                <div className="lg:col-span-6 h-full">
                  <PdfLivePreview
                    images={images}
                    settings={settings}
                    activePageIndex={activePageIndex}
                    onSelectPage={setActivePageIndex}
                    onRotateImage={handleRotateImage}
                  />
                </div>

                {/* Right Panel: PDF Customization Settings (3 cols) */}
                <div className="lg:col-span-3 h-full">
                  <PdfSettingsPanel
                    settings={settings}
                    onChangeSettings={setSettings}
                    onResetSettings={() => setSettings(DEFAULT_SETTINGS)}
                  />
                </div>
              </div>

              {/* Bottom Sticky Action Banner on Mobile/Desktop */}
              <div className="p-4 bg-gradient-to-r from-indigo-900 to-slate-900 text-white rounded-2xl shadow-xl flex flex-wrap items-center justify-between gap-4 border border-indigo-700/50">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-indigo-500/20 border border-indigo-400/30 flex items-center justify-center text-indigo-300">
                    <Sparkles className="w-5 h-5 text-amber-300" />
                  </div>
                  <div>
                    <div className="font-bold text-sm sm:text-base">
                      Ready to compile {images.length} {images.length === 1 ? 'image' : 'images'} into PDF
                    </div>
                    <div className="text-xs text-indigo-200">
                      Page Size: {settings.pageSize.toUpperCase()} • Orientation: {settings.orientation} • Quality: {settings.quality}
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <button
                    onClick={handleClearAll}
                    className="px-4 py-2.5 rounded-xl border border-slate-700 text-slate-300 hover:text-white hover:bg-slate-800 text-xs font-semibold transition-colors"
                  >
                    Clear All
                  </button>
                  <button
                    id="create-pdf-bottom-button"
                    onClick={handleCreatePdf}
                    className="px-8 py-3 rounded-xl font-bold text-slate-900 bg-white hover:bg-slate-100 active:bg-slate-200 shadow-lg shadow-white/10 hover:scale-105 transition-all text-sm flex items-center gap-2 cursor-pointer"
                  >
                    <Download className="w-4 h-4 text-indigo-600" />
                    <span>Create & Download PDF</span>
                  </button>
                </div>
              </div>
            </div>
          )}
        </section>

        {/* 4. Features Section */}
        <FeaturesSection />

        {/* 5. How It Works Section */}
        <HowItWorksSection />

        {/* 6. Privacy Promise Section */}
        <PrivacyBanner />

        {/* 7. FAQ Section */}
        <FaqSection />
      </main>

      {/* 8. Footer */}
      <Footer onNavigate={scrollToSection} />

      {/* Modals & Dialogs */}
      {/* Conversion Progress Modal */}
      {generationState.isGenerating && (
        <ConversionModal generationState={generationState} />
      )}

      {/* Success Modal */}
      {generationState.generatedBlob && !generationState.isGenerating && (
        <SuccessModal
          generationState={generationState}
          settings={settings}
          onClose={() =>
            setGenerationState((prev) => ({ ...prev, generatedBlob: null }))
          }
          onCreateAnother={() => {
            setGenerationState((prev) => ({
              ...prev,
              generatedBlob: null,
              generatedUrl: null,
            }));
            setImages([]);
            setActivePageIndex(0);
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
        />
      )}

      {/* Image Detail Inspector Modal */}
      {previewModalImage && (
        <ImagePreviewModal
          image={previewModalImage}
          onClose={() => setPreviewModalImage(null)}
          onRotate={handleRotateImage}
          onDelete={handleDeleteImage}
        />
      )}
    </div>
  );
}

import { UploadedImage } from '../types';

export function createSampleSvgImage(
  name: string,
  width: number,
  height: number,
  title: string,
  subtitle: string,
  bgGradient: [string, string],
  accentColor: string,
  iconShape: 'landscape' | 'document' | 'chart' | 'photo'
): Promise<UploadedImage> {
  return new Promise((resolve) => {
    let iconSvg = '';
    if (iconShape === 'landscape') {
      iconSvg = `
        <circle cx="200" cy="180" r="45" fill="#fef08a" opacity="0.9" />
        <path d="M 0 450 L 150 260 L 320 450 Z" fill="#475569" opacity="0.85" />
        <path d="M 180 450 L 380 200 L 580 450 Z" fill="#334155" />
        <path d="M 400 450 L 550 280 L 700 450 Z" fill="#1e293b" opacity="0.9" />
        <rect x="0" y="440" width="800" height="160" fill="#0f172a" />
      `;
    } else if (iconShape === 'document') {
      iconSvg = `
        <rect x="180" y="100" width="440" height="600" rx="16" fill="#ffffff" stroke="#cbd5e1" stroke-width="4" />
        <rect x="220" y="150" width="160" height="24" rx="6" fill="${accentColor}" />
        <rect x="220" y="210" width="360" height="14" rx="4" fill="#94a3b8" />
        <rect x="220" y="240" width="320" height="14" rx="4" fill="#cbd5e1" />
        <rect x="220" y="270" width="340" height="14" rx="4" fill="#cbd5e1" />
        <line x1="220" y1="330" x2="580" y2="330" stroke="#e2e8f0" stroke-width="2" />
        <rect x="220" y="360" width="100" height="20" rx="4" fill="#64748b" />
        <rect x="480" y="360" width="100" height="20" rx="4" fill="#64748b" />
        <rect x="220" y="410" width="360" height="36" rx="8" fill="#f1f5f9" />
        <rect x="220" y="460" width="360" height="36" rx="8" fill="#f8fafc" />
        <rect x="220" y="510" width="360" height="36" rx="8" fill="#f1f5f9" />
        <circle cx="530" cy="620" r="30" fill="${accentColor}" opacity="0.2" />
      `;
    } else if (iconShape === 'chart') {
      iconSvg = `
        <rect x="100" y="380" width="80" height="140" rx="8" fill="#38bdf8" />
        <rect x="220" y="280" width="80" height="240" rx="8" fill="#818cf8" />
        <rect x="340" y="200" width="80" height="320" rx="8" fill="#c084fc" />
        <rect x="460" y="140" width="80" height="380" rx="8" fill="${accentColor}" />
        <path d="M 140 370 Q 260 250, 380 180 T 500 130" fill="none" stroke="#f8fafc" stroke-width="6" stroke-linecap="round" />
        <circle cx="500" cy="130" r="10" fill="#f8fafc" />
      `;
    } else {
      iconSvg = `
        <circle cx="400" cy="280" r="140" fill="none" stroke="${accentColor}" stroke-width="12" opacity="0.6" />
        <polygon points="400,180 490,340 310,340" fill="${accentColor}" opacity="0.8" />
      `;
    }

    const svgString = `
      <svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}" viewBox="0 0 ${width} ${height}">
        <defs>
          <linearGradient id="grad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stop-color="${bgGradient[0]}" />
            <stop offset="100%" stop-color="${bgGradient[1]}" />
          </linearGradient>
        </defs>
        <rect width="${width}" height="${height}" fill="url(#grad)" />
        ${iconSvg}
        <rect x="30" y="${height - 110}" width="${width - 60}" height="80" rx="12" fill="rgba(15, 23, 42, 0.75)" backdrop-filter="blur(10px)" />
        <text x="50" y="${height - 65}" font-family="system-ui, sans-serif" font-size="24" font-weight="bold" fill="#ffffff">${title}</text>
        <text x="50" y="${height - 40}" font-family="system-ui, sans-serif" font-size="14" fill="#94a3b8">${subtitle}</text>
      </svg>
    `;

    const blob = new Blob([svgString], { type: 'image/svg+xml' });
    const url = URL.createObjectURL(blob);

    const img = new Image();
    img.onload = () => {
      // Draw to canvas to get standard raster image (PNG)
      const canvas = document.createElement('canvas');
      canvas.width = width;
      canvas.height = height;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.drawImage(img, 0, 0);
        const pngUrl = canvas.toDataURL('image/png');
        resolve({
          id: 'sample-' + Math.random().toString(36).substring(2, 9),
          name,
          size: Math.round(width * height * 0.4),
          type: 'image/png',
          src: pngUrl,
          width,
          height,
          rotation: 0,
          aspectRatio: width / height,
        });
      }
    };
    img.src = url;
  });
}

export async function getSampleImages(): Promise<UploadedImage[]> {
  return Promise.all([
    createSampleSvgImage(
      '01_Sunset_Mountain_View.png',
      800,
      600,
      'Alpine Sunset Expedition',
      'High-res photography • Landscape 4:3',
      ['#0f172a', '#3b82f6'],
      '#60a5fa',
      'landscape'
    ),
    createSampleSvgImage(
      '02_Invoice_Summary_Report.png',
      600,
      850,
      'Quarterly Financial Summary',
      'Scanned Document • Portrait A4',
      ['#f8fafc', '#e2e8f0'],
      '#4f46e5',
      'document'
    ),
    createSampleSvgImage(
      '03_Growth_Analytics_Chart.png',
      800,
      600,
      'Product Performance Matrix',
      'Vector Graphics • 16:9 Overview',
      ['#1e1b4b', '#4338ca'],
      '#a855f7',
      'chart'
    ),
    createSampleSvgImage(
      '04_Architectural_Design_Study.png',
      600,
      800,
      'Modern Structural Concept',
      'Design Draft • Portrait Canvas',
      ['#09090b', '#27272a'],
      '#10b981',
      'photo'
    ),
  ]);
}

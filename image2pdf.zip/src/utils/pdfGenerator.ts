import { jsPDF } from 'jspdf';
import { UploadedImage, PdfSettings, PageDimensionsMm } from '../types';

export const PAGE_SIZES_MM: Record<string, PageDimensionsMm> = {
  a4: { width: 210, height: 297 },
  a3: { width: 297, height: 420 },
  letter: { width: 215.9, height: 279.4 },
  legal: { width: 215.9, height: 355.6 },
};

export const MARGINS_MM: Record<string, number> = {
  none: 0,
  small: 5,
  medium: 10,
  large: 20,
};

export const QUALITY_VALUES: Record<string, number> = {
  high: 0.95,
  medium: 0.8,
  low: 0.6,
};

/**
 * Returns the effective dimensions of a page in millimeters based on settings and image
 */
export function getPageDimensions(
  settings: PdfSettings,
  img: UploadedImage
): { width: number; height: number; orientation: 'p' | 'l' } {
  // If rotation is 90 or 270, effective image aspect ratio is flipped
  const isRotated90or270 = img.rotation === 90 || img.rotation === 270;
  const effectiveImgWidth = isRotated90or270 ? img.height : img.width;
  const effectiveImgHeight = isRotated90or270 ? img.width : img.height;
  const isImageLandscape = effectiveImgWidth > effectiveImgHeight;

  if (settings.pageSize === 'fit_image') {
    // Convert pixels to mm roughly at 96 DPI: 1px ≈ 0.264583 mm
    const pxToMm = 0.264583;
    const margin = settings.margins === 'custom' ? settings.customMargin : MARGINS_MM[settings.margins] || 0;
    const width = effectiveImgWidth * pxToMm + margin * 2;
    const height = effectiveImgHeight * pxToMm + margin * 2;
    const orientation = width > height ? 'l' : 'p';
    return { width, height, orientation };
  }

  let baseDim: PageDimensionsMm;
  if (settings.pageSize === 'custom') {
    baseDim = { width: Math.max(10, settings.customWidth), height: Math.max(10, settings.customHeight) };
  } else {
    baseDim = PAGE_SIZES_MM[settings.pageSize] || PAGE_SIZES_MM.a4;
  }

  let isLandscape = false;
  if (settings.orientation === 'landscape') {
    isLandscape = true;
  } else if (settings.orientation === 'portrait') {
    isLandscape = false;
  } else if (settings.orientation === 'auto') {
    isLandscape = isImageLandscape;
  }

  const width = isLandscape ? Math.max(baseDim.width, baseDim.height) : Math.min(baseDim.width, baseDim.height);
  const height = isLandscape ? Math.min(baseDim.width, baseDim.height) : Math.max(baseDim.width, baseDim.height);

  return {
    width,
    height,
    orientation: isLandscape ? 'l' : 'p',
  };
}

/**
 * Creates an offscreen canvas rendering the image with rotation and exports as base64 JPEG
 */
export async function getProcessedImageData(
  image: UploadedImage,
  qualityPreset: 'high' | 'medium' | 'low'
): Promise<{ dataUrl: string; width: number; height: number }> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      if (!ctx) {
        reject(new Error('Canvas context unavailable'));
        return;
      }

      const rot = (image.rotation % 360 + 360) % 360;
      const is90or270 = rot === 90 || rot === 270;

      canvas.width = is90or270 ? img.height : img.width;
      canvas.height = is90or270 ? img.width : img.height;

      ctx.save();
      ctx.translate(canvas.width / 2, canvas.height / 2);
      ctx.rotate((rot * Math.PI) / 180);
      ctx.drawImage(img, -img.width / 2, -img.height / 2);
      ctx.restore();

      const quality = QUALITY_VALUES[qualityPreset] || 0.9;
      // Use image/jpeg for smaller PDF payload and broad compatibility
      const dataUrl = canvas.toDataURL('image/jpeg', quality);
      resolve({
        dataUrl,
        width: canvas.width,
        height: canvas.height,
      });
    };
    img.onerror = (e) => reject(new Error('Failed to load image for processing: ' + e));
    img.src = image.src;
  });
}

/**
 * Calculates image placement coordinates (x, y, w, h) in mm within the page bounds
 */
export function calculateImagePlacement(
  pageWidth: number,
  pageHeight: number,
  margin: number,
  imgWidth: number,
  imgHeight: number,
  fit: 'contain' | 'cover' | 'original' | 'stretch'
): { x: number; y: number; w: number; h: number } {
  const contentWidth = Math.max(1, pageWidth - margin * 2);
  const contentHeight = Math.max(1, pageHeight - margin * 2);
  const imgAspect = imgWidth / imgHeight;
  const contentAspect = contentWidth / contentHeight;

  let w = contentWidth;
  let h = contentHeight;
  let x = margin;
  let y = margin;

  if (fit === 'contain') {
    if (imgAspect > contentAspect) {
      w = contentWidth;
      h = contentWidth / imgAspect;
      x = margin;
      y = margin + (contentHeight - h) / 2;
    } else {
      h = contentHeight;
      w = contentHeight * imgAspect;
      x = margin + (contentWidth - w) / 2;
      y = margin;
    }
  } else if (fit === 'cover') {
    if (imgAspect > contentAspect) {
      h = contentHeight;
      w = contentHeight * imgAspect;
      x = margin + (contentWidth - w) / 2;
      y = margin;
    } else {
      w = contentWidth;
      h = contentWidth / imgAspect;
      x = margin;
      y = margin + (contentHeight - h) / 2;
    }
  } else if (fit === 'original') {
    // 1px ≈ 0.264583 mm
    const pxToMm = 0.264583;
    const rawW = imgWidth * pxToMm;
    const rawH = imgHeight * pxToMm;
    // Cap to page bounds if larger
    const scale = Math.min(1, contentWidth / rawW, contentHeight / rawH);
    w = rawW * scale;
    h = rawH * scale;
    x = margin + (contentWidth - w) / 2;
    y = margin + (contentHeight - h) / 2;
  } else if (fit === 'stretch') {
    w = contentWidth;
    h = contentHeight;
    x = margin;
    y = margin;
  }

  return { x, y, w, h };
}

/**
 * Generates the complete PDF from uploaded images and settings
 */
export async function generatePdf(
  images: UploadedImage[],
  settings: PdfSettings,
  onProgress?: (progress: number, stepText: string) => void
): Promise<{ blob: Blob; url: string; size: number; pageCount: number }> {
  if (images.length === 0) {
    throw new Error('No images to convert.');
  }

  const total = images.length;
  onProgress?.(5, 'Initializing PDF document...');

  // Initialize jsPDF with unit 'mm'
  const firstImage = images[0];
  const firstDim = getPageDimensions(settings, firstImage);

  const doc = new jsPDF({
    orientation: firstDim.orientation,
    unit: 'mm',
    format: [firstDim.width, firstDim.height],
    compress: true,
  });

  const marginMm = settings.margins === 'custom' ? settings.customMargin : MARGINS_MM[settings.margins] || 0;

  for (let i = 0; i < images.length; i++) {
    const currentImg = images[i];
    const pageNum = i + 1;
    const progressPercent = Math.round(10 + (i / total) * 80);

    onProgress?.(
      progressPercent,
      `Processing image ${pageNum} of ${total}: ${currentImg.name}...`
    );

    const pageDim = getPageDimensions(settings, currentImg);

    if (i > 0) {
      doc.addPage([pageDim.width, pageDim.height], pageDim.orientation);
    }

    // Set background color
    if (settings.backgroundColor && settings.backgroundColor !== 'transparent') {
      const hex = settings.backgroundColor.replace('#', '');
      if (hex.length === 6) {
        const r = parseInt(hex.substring(0, 2), 16);
        const g = parseInt(hex.substring(2, 4), 16);
        const b = parseInt(hex.substring(4, 6), 16);
        doc.setFillColor(r, g, b);
        doc.rect(0, 0, pageDim.width, pageDim.height, 'F');
      }
    }

    // Process image with rotation and compression
    const processed = await getProcessedImageData(currentImg, settings.quality);

    // Calculate placement
    const placement = calculateImagePlacement(
      pageDim.width,
      pageDim.height,
      marginMm,
      processed.width,
      processed.height,
      settings.imageFit
    );

    // Add image to PDF
    doc.addImage(
      processed.dataUrl,
      'JPEG',
      placement.x,
      placement.y,
      placement.w,
      placement.h,
      undefined,
      'FAST'
    );

    // Add Header Text if specified
    if (settings.headerText.trim()) {
      doc.setFontSize(8);
      doc.setTextColor(100, 116, 139);
      doc.text(settings.headerText.trim(), marginMm > 5 ? marginMm : 10, 7, { baseline: 'top' });
    }

    // Add Footer Text if specified
    if (settings.footerText.trim()) {
      doc.setFontSize(8);
      doc.setTextColor(100, 116, 139);
      doc.text(settings.footerText.trim(), marginMm > 5 ? marginMm : 10, pageDim.height - 5, { baseline: 'bottom' });
    }

    // Add Page Numbers
    if (settings.pageNumbers) {
      doc.setFontSize(9);
      doc.setTextColor(120, 120, 120);

      let text = `${pageNum}`;
      if (settings.pageNumberFormat === 'page_of_total') {
        text = `Page ${pageNum} of ${total}`;
      } else if (settings.pageNumberFormat === 'simple') {
        text = `${pageNum} / ${total}`;
      }

      let px = pageDim.width / 2;
      let py = pageDim.height - 6;
      let align: 'center' | 'right' | 'left' = 'center';

      if (settings.pageNumberPosition === 'bottom-right') {
        px = pageDim.width - (marginMm > 5 ? marginMm : 10);
        py = pageDim.height - 6;
        align = 'right';
      } else if (settings.pageNumberPosition === 'top-right') {
        px = pageDim.width - (marginMm > 5 ? marginMm : 10);
        py = 7;
        align = 'right';
      } else if (settings.pageNumberPosition === 'bottom-left') {
        px = marginMm > 5 ? marginMm : 10;
        py = pageDim.height - 6;
        align = 'left';
      }

      doc.text(text, px, py, { align });
    }
  }

  onProgress?.(95, 'Finalizing PDF buffer...');

  const outputBlob = doc.output('blob');
  const url = URL.createObjectURL(outputBlob);

  onProgress?.(100, 'PDF Ready!');

  return {
    blob: outputBlob,
    url,
    size: outputBlob.size,
    pageCount: total,
  };
}

import React, { useState, useRef, useEffect } from 'react';
import { UploadCloud, Image as ImageIcon, Sparkles, AlertCircle, FileCheck, Plus } from 'lucide-react';
import { UploadedImage } from '../types';

interface DropzoneProps {
  onImagesAdded: (images: UploadedImage[]) => void;
  inputRef?: React.RefObject<HTMLInputElement | null>;
  compact?: boolean;
}

export const Dropzone: React.FC<DropzoneProps> = ({
  onImagesAdded,
  inputRef: externalInputRef,
  compact = false,
}) => {
  const [isDragging, setIsDragging] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [processedCount, setProcessedCount] = useState(0);
  const [totalToProcess, setTotalToProcess] = useState(0);

  const internalInputRef = useRef<HTMLInputElement | null>(null);
  const fileInputRef = externalInputRef || internalInputRef;

  // Handle global paste event for quick clipboard uploads
  useEffect(() => {
    const handlePaste = (e: ClipboardEvent) => {
      const items = e.clipboardData?.items;
      if (!items) return;

      const imageFiles: File[] = [];
      for (let i = 0; i < items.length; i++) {
        if (items[i].type.startsWith('image/')) {
          const file = items[i].getAsFile();
          if (file) imageFiles.push(file);
        }
      }

      if (imageFiles.length > 0) {
        processFiles(imageFiles);
      }
    };

    window.addEventListener('paste', handlePaste);
    return () => window.removeEventListener('paste', handlePaste);
  }, []);

  const processFiles = async (files: FileList | File[]) => {
    setErrorMessage(null);
    const validFiles: File[] = [];
    const validExtensions = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp', 'image/gif', 'image/svg+xml'];

    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      if (
        validExtensions.includes(file.type.toLowerCase()) ||
        file.name.match(/\.(jpg|jpeg|png|webp|gif|svg)$/i)
      ) {
        validFiles.push(file);
      }
    }

    if (validFiles.length === 0) {
      setErrorMessage('Please select valid image files (JPG, JPEG, PNG, WEBP).');
      return;
    }

    setIsProcessing(true);
    setTotalToProcess(validFiles.length);
    setProcessedCount(0);

    const loadedImages: UploadedImage[] = [];

    for (let i = 0; i < validFiles.length; i++) {
      const file = validFiles[i];
      try {
        const uploadedImg = await readFileAsUploadedImage(file);
        loadedImages.push(uploadedImg);
        setProcessedCount((prev) => prev + 1);
      } catch (err) {
        console.warn(`Skipping corrupted file ${file.name}:`, err);
      }
    }

    setIsProcessing(false);

    if (loadedImages.length > 0) {
      onImagesAdded(loadedImages);
    } else {
      setErrorMessage('Could not process the selected images. Please verify they are not corrupted.');
    }
  };

  const readFileAsUploadedImage = (file: File): Promise<UploadedImage> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        const src = e.target?.result as string;
        const img = new Image();
        img.onload = () => {
          resolve({
            id: 'img-' + Date.now() + '-' + Math.random().toString(36).substring(2, 9),
            name: file.name,
            size: file.size,
            type: file.type || 'image/png',
            src,
            width: img.naturalWidth || img.width || 800,
            height: img.naturalHeight || img.height || 600,
            rotation: 0,
            aspectRatio: (img.naturalWidth || 800) / (img.naturalHeight || 600),
          });
        };
        img.onerror = () => reject(new Error('Failed to read image dimensions'));
        img.src = src;
      };
      reader.onerror = () => reject(new Error('Failed to read file'));
      reader.readAsDataURL(file);
    });
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      processFiles(e.dataTransfer.files);
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      processFiles(e.target.files);
      // Reset input value so same files can be re-uploaded if desired
      e.target.value = '';
    }
  };

  if (compact) {
    return (
      <div className="relative">
        <input
          id="compact-file-upload-input"
          ref={fileInputRef}
          type="file"
          multiple
          accept="image/jpeg,image/jpg,image/png,image/webp,image/gif,image/svg+xml,.jpg,.jpeg,.png,.webp,.gif,.svg"
          onChange={handleInputChange}
          className="sr-only"
        />
        <button
          type="button"
          onClick={() => fileInputRef.current?.click()}
          className="w-full py-2.5 px-3 rounded-xl border border-dashed border-indigo-300 dark:border-indigo-700 bg-indigo-50/50 dark:bg-indigo-950/30 hover:bg-indigo-50 dark:hover:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300 font-semibold text-xs flex items-center justify-center gap-2 transition-colors cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>Add More Images</span>
        </button>
      </div>
    );
  }

  return (
    <div className="w-full">
      {/* Hidden File Input */}
      <input
        id="file-upload-input"
        ref={fileInputRef}
        type="file"
        multiple
        accept="image/jpeg,image/jpg,image/png,image/webp,image/gif,image/svg+xml,.jpg,.jpeg,.png,.webp,.gif,.svg"
        onChange={handleInputChange}
        className="sr-only"
      />

      {/* Main Drag-and-Drop Area */}
      <div
        id="dropzone-area"
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        onClick={() => fileInputRef.current?.click()}
        className={`relative group rounded-3xl border-2 border-dashed transition-all duration-200 cursor-pointer overflow-hidden p-8 sm:p-12 text-center flex flex-col items-center justify-center ${
          isDragging
            ? 'border-indigo-500 bg-indigo-50/90 dark:bg-indigo-950/60 scale-[1.01] shadow-xl shadow-indigo-500/10'
            : 'border-slate-300 dark:border-slate-700 bg-white/70 dark:bg-slate-900/70 hover:border-indigo-400 dark:hover:border-indigo-600 hover:bg-slate-50/80 dark:hover:bg-slate-800/50 shadow-sm'
        }`}
      >
        {/* Decorative background glow */}
        <div className="absolute inset-0 bg-gradient-to-b from-indigo-500/5 to-transparent pointer-events-none" />

        {isProcessing ? (
          <div className="flex flex-col items-center py-4">
            <div className="w-16 h-16 rounded-2xl bg-indigo-100 dark:bg-indigo-950/80 text-indigo-600 dark:text-indigo-400 flex items-center justify-center mb-4 animate-pulse">
              <FileCheck className="w-8 h-8 animate-bounce" />
            </div>
            <h3 className="text-lg font-bold text-slate-800 dark:text-slate-200 mb-1">
              Processing {processedCount} of {totalToProcess} images...
            </h3>
            <div className="w-48 h-2 bg-slate-200 dark:bg-slate-700 rounded-full overflow-hidden mt-3">
              <div
                className="h-full bg-indigo-600 rounded-full transition-all duration-200"
                style={{ width: `${(processedCount / Math.max(1, totalToProcess)) * 100}%` }}
              />
            </div>
          </div>
        ) : (
          <>
            <div className="w-20 h-20 rounded-3xl bg-indigo-50 dark:bg-indigo-950/80 border border-indigo-100 dark:border-indigo-800/80 text-indigo-600 dark:text-indigo-400 flex items-center justify-center mb-5 group-hover:scale-110 group-hover:bg-indigo-600 group-hover:text-white transition-all shadow-sm">
              <UploadCloud className="w-10 h-10 transition-transform group-hover:-translate-y-0.5" />
            </div>

            <h3 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white mb-2">
              Drag & Drop your images here
            </h3>
            <p className="text-sm sm:text-base text-slate-500 dark:text-slate-400 max-w-md mb-6 font-normal">
              or click to browse from your device. You can also paste directly with <kbd className="px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 text-xs font-mono">Ctrl+V</kbd>.
            </p>

            <button
              type="button"
              id="dropzone-select-button"
              className="px-6 py-3 rounded-xl font-semibold text-sm text-white bg-indigo-600 group-hover:bg-indigo-500 active:bg-indigo-700 shadow-md shadow-indigo-600/20 transition-all flex items-center gap-2"
            >
              <ImageIcon className="w-4 h-4" />
              <span>Select Images to Convert</span>
            </button>

            {/* Supported Formats */}
            <div className="mt-8 flex flex-wrap items-center justify-center gap-2 text-xs font-medium text-slate-400 dark:text-slate-500">
              <span className="px-2.5 py-1 rounded-md bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700/60">
                JPG / JPEG
              </span>
              <span className="px-2.5 py-1 rounded-md bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700/60">
                PNG
              </span>
              <span className="px-2.5 py-1 rounded-md bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700/60">
                WEBP
              </span>
              <span className="px-2.5 py-1 rounded-md bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700/60">
                GIF & SVG
              </span>
            </div>
          </>
        )}
      </div>

      {/* Error Message */}
      {errorMessage && (
        <div className="mt-3 p-3 rounded-xl bg-rose-50 dark:bg-rose-950/50 border border-rose-200 dark:border-rose-800 text-rose-700 dark:text-rose-300 text-xs sm:text-sm flex items-center gap-2">
          <AlertCircle className="w-4 h-4 shrink-0 text-rose-500" />
          <span>{errorMessage}</span>
        </div>
      )}
    </div>
  );
};

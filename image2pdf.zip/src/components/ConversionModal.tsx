import React from 'react';
import { Loader2, Sparkles, FileText, Check } from 'lucide-react';
import { PdfGenerationState } from '../types';

interface ConversionModalProps {
  generationState: PdfGenerationState;
}

export const ConversionModal: React.FC<ConversionModalProps> = ({ generationState }) => {
  return (
    <div
      id="conversion-progress-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/70 backdrop-blur-sm"
    >
      <div
        id="conversion-progress-card"
        className="w-full max-w-md bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl p-6 sm:p-8 text-center"
      >
        <div className="w-16 h-16 rounded-2xl bg-indigo-50 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-400 flex items-center justify-center mx-auto mb-5 shadow-inner">
          <Loader2 className="w-8 h-8 animate-spin text-indigo-600 dark:text-indigo-400" />
        </div>

        <h3 className="text-xl sm:text-2xl font-extrabold text-slate-900 dark:text-white tracking-tight mb-2">
          Generating Your PDF...
        </h3>

        <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 font-medium mb-6">
          {generationState.currentStepText || 'Processing images and building layout...'}
        </p>

        {/* Progress Bar */}
        <div className="w-full bg-slate-100 dark:bg-slate-800 rounded-full h-3.5 p-0.5 overflow-hidden mb-3 border border-slate-200 dark:border-slate-700">
          <div
            className="h-full bg-gradient-to-r from-indigo-500 via-indigo-600 to-violet-600 rounded-full transition-all duration-300"
            style={{ width: `${Math.max(5, generationState.progress)}%` }}
          />
        </div>

        <div className="flex items-center justify-between text-xs font-semibold text-slate-400">
          <span>Processing locally</span>
          <span>{generationState.progress}%</span>
        </div>
      </div>
    </div>
  );
};

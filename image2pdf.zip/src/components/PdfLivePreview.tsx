import React, { useRef, useEffect, useState } from 'react';
import {
  ChevronLeft,
  ChevronRight,
  ZoomIn,
  ZoomOut,
  Maximize2,
  Minimize2,
  LayoutGrid,
  FileText,
  RotateCw,
  Eye,
  SlidersHorizontal,
} from 'lucide-react';
import { UploadedImage, PdfSettings } from '../types';
import {
  getPageDimensions,
  calculateImagePlacement,
  MARGINS_MM,
} from '../utils/pdfGenerator';

interface PdfLivePreviewProps {
  images: UploadedImage[];
  settings: PdfSettings;
  activePageIndex: number;
  onSelectPage: (index: number) => void;
  onRotateImage?: (id: string, delta: number) => void;
}

export const PdfLivePreview: React.FC<PdfLivePreviewProps> = ({
  images,
  settings,
  activePageIndex,
  onSelectPage,
  onRotateImage,
}) => {
  const [zoomLevel, setZoomLevel] = useState<number>(100);
  const [viewMode, setViewMode] = useState<'single' | 'grid'>('single');
  const [showMarginGuide, setShowMarginGuide] = useState<boolean>(true);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  const activeImage = images[activePageIndex] || images[0];

  // Draw the current page accurately onto canvas
  useEffect(() => {
    if (!activeImage || viewMode !== 'single' || !canvasRef.current) return;

    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const pageDim = getPageDimensions(settings, activeImage);
    const marginMm = settings.margins === 'custom' ? settings.customMargin : MARGINS_MM[settings.margins] || 0;

    // We render at high DPI resolution for crisp rendering
    // Scale mm to canvas pixels (e.g. 3 px per mm for preview canvas = ~800-1200px width)
    const scaleFactor = 3.5;
    const canvasW = Math.round(pageDim.width * scaleFactor);
    const canvasH = Math.round(pageDim.height * scaleFactor);

    canvas.width = canvasW;
    canvas.height = canvasH;

    // 1. Draw Page Background
    if (settings.backgroundColor && settings.backgroundColor !== 'transparent') {
      ctx.fillStyle = settings.backgroundColor;
      ctx.fillRect(0, 0, canvasW, canvasH);
    } else {
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(0, 0, canvasW, canvasH);
    }

    // 2. Optional: Draw Margin Guideline (subtle dashed line)
    if (showMarginGuide && marginMm > 0) {
      ctx.save();
      ctx.strokeStyle = '#6366f140';
      ctx.lineWidth = 1.5;
      ctx.setLineDash([6, 6]);
      const mx = marginMm * scaleFactor;
      const my = marginMm * scaleFactor;
      const mw = (pageDim.width - marginMm * 2) * scaleFactor;
      const mh = (pageDim.height - marginMm * 2) * scaleFactor;
      ctx.strokeRect(mx, my, mw, mh);
      ctx.restore();
    }

    // 3. Load and draw rotated image with correct fit
    const imgObj = new Image();
    imgObj.crossOrigin = 'anonymous';
    imgObj.onload = () => {
      // Offscreen canvas for rotation
      const offCanvas = document.createElement('canvas');
      const offCtx = offCanvas.getContext('2d');
      if (!offCtx) return;

      const rot = (activeImage.rotation % 360 + 360) % 360;
      const is90or270 = rot === 90 || rot === 270;
      const effImgW = is90or270 ? imgObj.height : imgObj.width;
      const effImgH = is90or270 ? imgObj.width : imgObj.height;

      offCanvas.width = effImgW;
      offCanvas.height = effImgH;

      offCtx.save();
      offCtx.translate(offCanvas.width / 2, offCanvas.height / 2);
      offCtx.rotate((rot * Math.PI) / 180);
      offCtx.drawImage(imgObj, -imgObj.width / 2, -imgObj.height / 2);
      offCtx.restore();

      // Calculate placement
      const placement = calculateImagePlacement(
        pageDim.width,
        pageDim.height,
        marginMm,
        effImgW,
        effImgH,
        settings.imageFit
      );

      // Draw onto preview canvas
      ctx.drawImage(
        offCanvas,
        placement.x * scaleFactor,
        placement.y * scaleFactor,
        placement.w * scaleFactor,
        placement.h * scaleFactor
      );

      // 4. Header Text
      if (settings.headerText.trim()) {
        ctx.font = '14px system-ui, sans-serif';
        ctx.fillStyle = '#64748b';
        ctx.textAlign = 'left';
        ctx.fillText(
          settings.headerText.trim(),
          Math.max(10, marginMm) * scaleFactor,
          20 * scaleFactor
        );
      }

      // 5. Footer Text
      if (settings.footerText.trim()) {
        ctx.font = '14px system-ui, sans-serif';
        ctx.fillStyle = '#64748b';
        ctx.textAlign = 'left';
        ctx.fillText(
          settings.footerText.trim(),
          Math.max(10, marginMm) * scaleFactor,
          (pageDim.height - 8) * scaleFactor
        );
      }

      // 6. Page Numbers
      if (settings.pageNumbers) {
        ctx.font = 'bold 15px system-ui, sans-serif';
        ctx.fillStyle = '#475569';

        const pageNum = activePageIndex + 1;
        const total = images.length;
        let text = `${pageNum}`;
        if (settings.pageNumberFormat === 'page_of_total') {
          text = `Page ${pageNum} of ${total}`;
        } else if (settings.pageNumberFormat === 'simple') {
          text = `${pageNum} / ${total}`;
        }

        let px = (pageDim.width / 2) * scaleFactor;
        let py = (pageDim.height - 8) * scaleFactor;
        ctx.textAlign = 'center';

        if (settings.pageNumberPosition === 'bottom-right') {
          px = (pageDim.width - Math.max(10, marginMm)) * scaleFactor;
          py = (pageDim.height - 8) * scaleFactor;
          ctx.textAlign = 'right';
        } else if (settings.pageNumberPosition === 'top-right') {
          px = (pageDim.width - Math.max(10, marginMm)) * scaleFactor;
          py = 20 * scaleFactor;
          ctx.textAlign = 'right';
        } else if (settings.pageNumberPosition === 'bottom-left') {
          px = Math.max(10, marginMm) * scaleFactor;
          py = (pageDim.height - 8) * scaleFactor;
          ctx.textAlign = 'left';
        }

        ctx.fillText(text, px, py);
      }
    };
    imgObj.src = activeImage.src;
  }, [activeImage, settings, activePageIndex, viewMode, showMarginGuide, images.length]);

  if (images.length === 0) {
    return null;
  }

  const currentPageDim = activeImage ? getPageDimensions(settings, activeImage) : { width: 210, height: 297, orientation: 'p' };

  return (
    <div className="flex flex-col h-full bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl shadow-sm overflow-hidden">
      {/* Top Toolbar */}
      <div className="p-3 sm:px-4 border-b border-slate-200/80 dark:border-slate-800 bg-slate-50/80 dark:bg-slate-950/40 flex flex-wrap items-center justify-between gap-3">
        {/* Page Switcher */}
        <div className="flex items-center gap-1 sm:gap-2">
          <button
            id="prev-page-button"
            disabled={activePageIndex === 0}
            onClick={() => onSelectPage(Math.max(0, activePageIndex - 1))}
            className="p-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-700 disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
            title="Previous Page (←)"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>

          <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-700 dark:text-slate-200">
            <span>Page</span>
            <input
              type="number"
              min={1}
              max={images.length}
              value={activePageIndex + 1}
              onChange={(e) => {
                const val = parseInt(e.target.value, 10);
                if (!isNaN(val) && val >= 1 && val <= images.length) {
                  onSelectPage(val - 1);
                }
              }}
              className="w-8 text-center bg-slate-100 dark:bg-slate-900 rounded border border-slate-200 dark:border-slate-700 py-0.5 font-bold focus:outline-none focus:ring-1 focus:ring-indigo-500"
            />
            <span className="text-slate-400">/ {images.length}</span>
          </div>

          <button
            id="next-page-button"
            disabled={activePageIndex >= images.length - 1}
            onClick={() => onSelectPage(Math.min(images.length - 1, activePageIndex + 1))}
            className="p-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-700 disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
            title="Next Page (→)"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>

        {/* Dimension Badge */}
        <div className="hidden lg:flex items-center gap-2 text-xs font-medium text-slate-500 dark:text-slate-400 px-2.5 py-1 rounded-md bg-slate-100 dark:bg-slate-800/80">
          <FileText className="w-3.5 h-3.5 text-indigo-500" />
          <span>
            {settings.pageSize.toUpperCase()} {currentPageDim.orientation === 'l' ? 'Landscape' : 'Portrait'} ({Math.round(currentPageDim.width)} × {Math.round(currentPageDim.height)} mm)
          </span>
        </div>

        {/* View Mode & Zoom Controls */}
        <div className="flex items-center gap-1 sm:gap-2">
          {/* Margin guide toggle */}
          <button
            onClick={() => setShowMarginGuide(!showMarginGuide)}
            title="Toggle margin guidelines"
            className={`p-1.5 rounded-lg border text-xs font-semibold flex items-center gap-1 transition-colors ${
              showMarginGuide
                ? 'bg-indigo-50 dark:bg-indigo-950/60 border-indigo-200 dark:border-indigo-800 text-indigo-600 dark:text-indigo-400'
                : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
            }`}
          >
            <SlidersHorizontal className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Guides</span>
          </button>

          {/* View mode toggle */}
          <div className="flex items-center bg-slate-200/70 dark:bg-slate-800 p-0.5 rounded-lg">
            <button
              id="view-single-button"
              onClick={() => setViewMode('single')}
              title="Single page view"
              className={`p-1.5 rounded-md transition-all ${
                viewMode === 'single'
                  ? 'bg-white dark:bg-slate-700 text-indigo-600 dark:text-indigo-400 shadow-xs'
                  : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
              }`}
            >
              <FileText className="w-3.5 h-3.5" />
            </button>
            <button
              id="view-grid-button"
              onClick={() => setViewMode('grid')}
              title="All pages grid overview"
              className={`p-1.5 rounded-md transition-all ${
                viewMode === 'grid'
                  ? 'bg-white dark:bg-slate-700 text-indigo-600 dark:text-indigo-400 shadow-xs'
                  : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
              }`}
            >
              <LayoutGrid className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Zoom controls (Single view only) */}
          {viewMode === 'single' && (
            <div className="flex items-center gap-1">
              <button
                id="zoom-out-button"
                onClick={() => setZoomLevel((prev) => Math.max(50, prev - 15))}
                title="Zoom out"
                className="p-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-50 transition-colors"
              >
                <ZoomOut className="w-3.5 h-3.5" />
              </button>
              <span className="text-xs font-mono font-semibold text-slate-600 dark:text-slate-400 w-10 text-center">
                {zoomLevel}%
              </span>
              <button
                id="zoom-in-button"
                onClick={() => setZoomLevel((prev) => Math.min(200, prev + 15))}
                title="Zoom in"
                className="p-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-50 transition-colors"
              >
                <ZoomIn className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={() => setZoomLevel(100)}
                title="Reset zoom to 100%"
                className="px-2 py-1 text-[11px] font-semibold rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-50"
              >
                Fit
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Main Preview Canvas Area */}
      <div className="flex-1 overflow-auto p-4 sm:p-8 flex items-center justify-center bg-slate-100/80 dark:bg-slate-950/80 min-h-[460px] relative">
        {viewMode === 'single' ? (
          <div
            className="transition-all duration-200 ease-out flex items-center justify-center"
            style={{
              transform: `scale(${zoomLevel / 100})`,
              transformOrigin: 'center center',
            }}
          >
            <div className="relative shadow-2xl rounded-sm border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 transition-shadow">
              <canvas
                id="live-pdf-canvas"
                ref={canvasRef}
                className="max-w-[85vw] max-h-[65vh] object-contain rounded-sm"
              />
            </div>
          </div>
        ) : (
          /* Grid View of all pages */
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6 w-full max-w-4xl p-2">
            {images.map((img, idx) => {
              const isCurrent = idx === activePageIndex;
              const dim = getPageDimensions(settings, img);
              const isLandscape = dim.orientation === 'l';

              return (
                <div
                  key={img.id}
                  onClick={() => {
                    onSelectPage(idx);
                    setViewMode('single');
                  }}
                  className={`group relative rounded-xl border p-3 flex flex-col items-center bg-white dark:bg-slate-900 cursor-pointer transition-all hover:shadow-lg ${
                    isCurrent
                      ? 'border-indigo-500 ring-2 ring-indigo-500/40 shadow-md'
                      : 'border-slate-200 dark:border-slate-800 hover:border-indigo-300'
                  }`}
                >
                  <div className="w-full flex items-center justify-between text-xs font-semibold mb-2 text-slate-500 dark:text-slate-400">
                    <span className="px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200">
                      Page {idx + 1}
                    </span>
                    <span className="text-[11px] truncate max-w-[120px]">{img.name}</span>
                  </div>

                  <div
                    className={`w-full bg-slate-50 dark:bg-slate-950 rounded-lg flex items-center justify-center p-2 border border-slate-100 dark:border-slate-800 relative overflow-hidden ${
                      isLandscape ? 'aspect-[4/3]' : 'aspect-[3/4]'
                    }`}
                  >
                    <img
                      src={img.src}
                      alt={img.name}
                      className="max-w-full max-h-full object-contain transition-transform"
                      style={{
                        transform: `rotate(${img.rotation}deg)`,
                      }}
                    />
                  </div>

                  <div className="mt-2 text-xs font-medium text-slate-400 dark:text-slate-500 flex items-center justify-between w-full">
                    <span>{img.width}×{img.height}px</span>
                    <span className="text-indigo-600 dark:text-indigo-400 group-hover:underline">Click to edit</span>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Bottom status indicator */}
      <div className="px-4 py-2 border-t border-slate-200/80 dark:border-slate-800 bg-white dark:bg-slate-900 flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
        <div className="flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
          <span>Live PDF Rendering Engine</span>
        </div>
        <div>
          {images.length} {images.length === 1 ? 'page' : 'pages'} ready to export
        </div>
      </div>
    </div>
  );
};

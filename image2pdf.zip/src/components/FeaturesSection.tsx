import React from 'react';
import {
  ShieldCheck,
  Zap,
  Layers,
  Sliders,
  Maximize2,
  FileCheck,
  Palette,
  Smartphone,
  Sparkles,
} from 'lucide-react';

export const FeaturesSection: React.FC = () => {
  const features = [
    {
      icon: ShieldCheck,
      title: '100% Client-Side Privacy',
      description:
        'Your photos and documents never touch a cloud server. All PDF compilation runs directly inside your browser memory.',
      badge: 'Zero Uploads',
    },
    {
      icon: Zap,
      title: 'Lightning Fast Conversion',
      description:
        'Instant compilation with hardware acceleration. Convert dozens of high-resolution images in mere fractions of a second.',
      badge: 'Instant',
    },
    {
      icon: Layers,
      title: 'Visual Drag & Drop Reordering',
      description:
        'Easily arrange your pages in any sequence. Drag thumbnails, move up/down, sort alphabetically or by file size.',
      badge: 'Intuitive',
    },
    {
      icon: Sliders,
      title: 'Complete Layout Control',
      description:
        'Switch between A4, Letter, Legal, A3 or Custom dimensions. Adjust margins, portrait/landscape, and contain/cover fits.',
      badge: 'Customizable',
    },
    {
      icon: Palette,
      title: 'Custom Styles & Numbers',
      description:
        'Add page numbering (e.g. "Page 1 of 10"), custom background colors, header titles, and footer notes.',
      badge: 'Professional',
    },
    {
      icon: Smartphone,
      title: 'Mobile & Tablet Friendly',
      description:
        'Responsive workspace designed for seamless conversion on phones, iPads, laptops, and ultra-wide desktop monitors.',
      badge: 'Responsive',
    },
  ];

  return (
    <section id="features" className="py-16 md:py-24 border-t border-slate-200/80 dark:border-slate-800/80 bg-slate-50/50 dark:bg-slate-900/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-14">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-950/60 border border-indigo-200 dark:border-indigo-800 mb-3">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Power & Simplicity</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-slate-900 dark:text-white">
            Everything You Need for Image to PDF
          </h2>
          <p className="text-slate-600 dark:text-slate-400 mt-3 text-base sm:text-lg">
            A comprehensive suite of formatting tools packaged into a sleek, clean interface without bloat.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature, idx) => {
            const Icon = feature.icon;
            return (
              <div
                key={idx}
                className="group relative p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 hover:border-indigo-400 dark:hover:border-indigo-600 shadow-sm hover:shadow-md transition-all duration-200 flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <div className="w-12 h-12 rounded-xl bg-indigo-50 dark:bg-indigo-950/80 text-indigo-600 dark:text-indigo-400 border border-indigo-100 dark:border-indigo-800/60 flex items-center justify-center group-hover:scale-110 transition-transform">
                      <Icon className="w-6 h-6" />
                    </div>
                    <span className="text-[11px] font-bold px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300">
                      {feature.badge}
                    </span>
                  </div>
                  <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-2">
                    {feature.title}
                  </h3>
                  <p className="text-sm text-slate-500 dark:text-slate-400 leading-relaxed">
                    {feature.description}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};

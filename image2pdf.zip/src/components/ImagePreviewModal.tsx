import React from 'react';
import { X, RotateCw, RotateCcw, Image as ImageIcon, Trash2 } from 'lucide-react';
import { UploadedImage } from '../types';

interface ImagePreviewModalProps {
  image: UploadedImage | null;
  onClose: () => void;
  onRotate: (id: string, delta: number) => void;
  onDelete: (id: string) => void;
}

export const ImagePreviewModal: React.FC<ImagePreviewModalProps> = ({
  image,
  onClose,
  onRotate,
  onDelete,
}) => {
  if (!image) return null;

  const sizeKb = (image.size / 1024).toFixed(1);
  const sizeMb = (image.size / (1024 * 1024)).toFixed(2);

  return (
    <div
      id="image-preview-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md"
      onClick={onClose}
    >
      <div
        id="image-preview-modal-card"
        className="relative w-full max-w-4xl max-h-[90vh] bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Header */}
        <div className="p-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between bg-slate-50/80 dark:bg-slate-950/50">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-indigo-50 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-400 flex items-center justify-center">
              <ImageIcon className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-sm text-slate-900 dark:text-white truncate max-w-sm sm:max-w-md">
                {image.name}
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                {image.width} × {image.height} px • {image.size > 1024 * 1024 ? `${sizeMb} MB` : `${sizeKb} KB`} • {image.type}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              onClick={() => onRotate(image.id, -90)}
              title="Rotate Left 90°"
              className="p-2 rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-200/70 dark:hover:bg-slate-800 transition-colors"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
            <button
              onClick={() => onRotate(image.id, 90)}
              title="Rotate Right 90°"
              className="p-2 rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-200/70 dark:hover:bg-slate-800 transition-colors"
            >
              <RotateCw className="w-4 h-4" />
            </button>
            <button
              onClick={() => {
                onDelete(image.id);
                onClose();
              }}
              title="Delete Image"
              className="p-2 rounded-xl text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/50 transition-colors"
            >
              <Trash2 className="w-4 h-4" />
            </button>
            <button
              onClick={onClose}
              className="p-2 rounded-xl text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-200/70 dark:hover:bg-slate-800 transition-colors ml-2"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Full Image Viewer */}
        <div className="flex-1 overflow-auto p-6 sm:p-10 flex items-center justify-center bg-checkered min-h-[350px]">
          <div className="relative max-w-full max-h-[60vh] flex items-center justify-center">
            <img
              src={image.src}
              alt={image.name}
              className="max-w-full max-h-[60vh] object-contain shadow-2xl rounded-lg transition-transform duration-300"
              style={{
                transform: `rotate(${image.rotation}deg)`,
              }}
            />
          </div>
        </div>

        {/* Footer info */}
        <div className="p-3 bg-slate-50 dark:bg-slate-950/60 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
          <span>Current Rotation: {image.rotation}°</span>
          <span>Aspect Ratio: {image.aspectRatio.toFixed(2)}</span>
        </div>
      </div>
    </div>
  );
};

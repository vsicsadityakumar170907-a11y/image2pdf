import React from 'react';
import { FileText, ShieldCheck, Heart, Sparkles } from 'lucide-react';

interface FooterProps {
  onNavigate: (sectionId: string) => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavigate }) => {
  return (
    <footer className="border-t border-slate-200/80 dark:border-slate-800 bg-white dark:bg-slate-950 py-12 transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          {/* Logo */}
          <div className="flex items-center gap-2.5 select-none">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-indigo-600 to-violet-500 flex items-center justify-center text-white shadow-sm">
              <FileText className="w-4 h-4" />
            </div>
            <span className="font-extrabold text-lg tracking-tight text-slate-900 dark:text-white">
              Image<span className="text-indigo-600 dark:text-indigo-400">2PDF</span>
            </span>
          </div>

          {/* Links */}
          <div className="flex flex-wrap items-center justify-center gap-6 text-xs sm:text-sm font-medium text-slate-500 dark:text-slate-400">
            <button onClick={() => onNavigate('converter')} className="hover:text-indigo-600 dark:hover:text-indigo-400">
              Converter
            </button>
            <button onClick={() => onNavigate('features')} className="hover:text-indigo-600 dark:hover:text-indigo-400">
              Features
            </button>
            <button onClick={() => onNavigate('how-it-works')} className="hover:text-indigo-600 dark:hover:text-indigo-400">
              How It Works
            </button>
            <button onClick={() => onNavigate('faq')} className="hover:text-indigo-600 dark:hover:text-indigo-400">
              FAQ
            </button>
            <button onClick={() => onNavigate('privacy')} className="hover:text-indigo-600 dark:hover:text-indigo-400 flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-500" />
              Privacy Promise
            </button>
          </div>

          {/* Copyright & Privacy Notice */}
          <div className="text-xs text-slate-400 dark:text-slate-500 text-center md:text-right">
            <span>Fast, Private, 100% In-Browser</span>
          </div>
        </div>
      </div>
    </footer>
  );
};

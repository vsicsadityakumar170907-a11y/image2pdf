import React, { useEffect } from 'react';
import confetti from 'canvas-confetti';
import {
  CheckCircle2,
  Download,
  ExternalLink,
  PlusCircle,
  FileText,
  Share2,
  Printer,
  Sparkles,
  X,
} from 'lucide-react';
import { PdfGenerationState, PdfSettings } from '../types';

interface SuccessModalProps {
  generationState: PdfGenerationState;
  settings: PdfSettings;
  onClose: () => void;
  onCreateAnother: () => void;
}

export const SuccessModal: React.FC<SuccessModalProps> = ({
  generationState,
  settings,
  onClose,
  onCreateAnother,
}) => {
  useEffect(() => {
    // Fire confetti cannon!
    try {
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 },
        colors: ['#6366f1', '#8b5cf6', '#ec4899', '#3b82f6', '#10b981'],
      });
    } catch (e) {
      console.log('Confetti effect:', e);
    }
  }, []);

  const handleDownload = () => {
    if (!generationState.generatedBlob) return;
    const filename = (settings.filename.trim() || 'document') + '.pdf';
    const a = document.createElement('a');
    a.href = generationState.generatedUrl || '';
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  const handleOpenInNewTab = () => {
    if (generationState.generatedUrl) {
      window.open(generationState.generatedUrl, '_blank');
    }
  };

  const fileSizeMb = (generationState.generatedSize / (1024 * 1024)).toFixed(2);
  const fileSizeKb = (generationState.generatedSize / 1024).toFixed(0);

  return (
    <div
      id="success-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-md animate-fade-in"
    >
      <div
        id="success-modal-card"
        className="relative w-full max-w-lg bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden p-6 sm:p-8 text-center"
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Success Icon */}
        <div className="w-20 h-20 rounded-3xl bg-emerald-50 dark:bg-emerald-950/80 border border-emerald-200 dark:border-emerald-800 text-emerald-600 dark:text-emerald-400 flex items-center justify-center mx-auto mb-5 shadow-inner">
          <CheckCircle2 className="w-10 h-10 animate-bounce" />
        </div>

        {/* Heading */}
        <h3 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight mb-2">
          Your PDF is Ready!
        </h3>
        <p className="text-sm text-slate-500 dark:text-slate-400 max-w-xs mx-auto mb-6">
          All images have been arranged, formatted, and converted successfully.
        </p>

        {/* File Stats Card */}
        <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/80 mb-6 text-left flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-indigo-100 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-400 flex items-center justify-center shrink-0">
            <FileText className="w-6 h-6" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="text-sm font-bold text-slate-900 dark:text-white truncate">
              {(settings.filename.trim() || 'document') + '.pdf'}
            </div>
            <div className="text-xs text-slate-500 dark:text-slate-400 flex items-center gap-3 mt-0.5">
              <span>{generationState.generatedPages} Pages</span>
              <span>•</span>
              <span>{generationState.generatedSize > 1024 * 1024 ? `${fileSizeMb} MB` : `${fileSizeKb} KB`}</span>
              <span>•</span>
              <span className="text-emerald-600 dark:text-emerald-400 font-semibold">100% Quality</span>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="space-y-2.5">
          <button
            id="download-pdf-button"
            onClick={handleDownload}
            className="w-full py-4 px-6 rounded-2xl font-bold text-white bg-indigo-600 hover:bg-indigo-500 active:bg-indigo-700 shadow-xl shadow-indigo-600/30 hover:shadow-indigo-600/40 transition-all flex items-center justify-center gap-2.5 text-base cursor-pointer hover:-translate-y-0.5 active:translate-y-0"
          >
            <Download className="w-5 h-5" />
            <span>Download PDF Now</span>
          </button>

          <div className="grid grid-cols-2 gap-2.5">
            <button
              id="preview-new-tab-button"
              onClick={handleOpenInNewTab}
              className="py-3 px-4 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 font-semibold text-xs hover:bg-slate-50 dark:hover:bg-slate-700 flex items-center justify-center gap-1.5 transition-colors"
            >
              <ExternalLink className="w-4 h-4 text-indigo-500" />
              <span>Open in New Tab</span>
            </button>

            <button
              id="create-another-pdf-button"
              onClick={onCreateAnother}
              className="py-3 px-4 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 font-semibold text-xs hover:bg-slate-50 dark:hover:bg-slate-700 flex items-center justify-center gap-1.5 transition-colors"
            >
              <PlusCircle className="w-4 h-4 text-slate-400" />
              <span>Create Another PDF</span>
            </button>
          </div>
        </div>

        {/* Privacy reassurance */}
        <div className="mt-6 text-[11px] text-slate-400 dark:text-slate-500">
          🔒 Downloaded directly from memory. Nothing was uploaded or stored on any server.
        </div>
      </div>
    </div>
  );
};

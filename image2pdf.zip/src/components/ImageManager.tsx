import React, { useState } from 'react';
import {
  GripVertical,
  RotateCw,
  RotateCcw,
  Trash2,
  Eye,
  ArrowUp,
  ArrowDown,
  ArrowUpDown,
  Compass,
  Sparkles,
  Layers,
} from 'lucide-react';
import { UploadedImage } from '../types';
import { Dropzone } from './Dropzone';

interface ImageManagerProps {
  images: UploadedImage[];
  activePageIndex: number;
  onSelectPage: (index: number) => void;
  onReorderImages: (images: UploadedImage[]) => void;
  onRotateImage: (id: string, deltaDegrees: number) => void;
  onDeleteImage: (id: string) => void;
  onClearAll: () => void;
  onAddImages: (newImages: UploadedImage[]) => void;
  onOpenPreviewModal: (image: UploadedImage) => void;
}

export const ImageManager: React.FC<ImageManagerProps> = ({
  images,
  activePageIndex,
  onSelectPage,
  onReorderImages,
  onRotateImage,
  onDeleteImage,
  onClearAll,
  onAddImages,
  onOpenPreviewModal,
}) => {
  const [draggedIndex, setDraggedIndex] = useState<number | null>(null);
  const [dragOverIndex, setDragOverIndex] = useState<number | null>(null);
  const [sortMenuOpen, setSortMenuOpen] = useState(false);

  const totalSizeMb = (
    images.reduce((acc, img) => acc + img.size, 0) / (1024 * 1024)
  ).toFixed(2);

  const handleDragStart = (e: React.DragEvent, index: number) => {
    setDraggedIndex(index);
    e.dataTransfer.effectAllowed = 'move';
    e.dataTransfer.setData('text/plain', index.toString());
  };

  const handleDragOver = (e: React.DragEvent, index: number) => {
    e.preventDefault();
    if (draggedIndex === null || draggedIndex === index) return;
    setDragOverIndex(index);
  };

  const handleDrop = (e: React.DragEvent, targetIndex: number) => {
    e.preventDefault();
    if (draggedIndex === null || draggedIndex === targetIndex) {
      setDraggedIndex(null);
      setDragOverIndex(null);
      return;
    }

    const newImages = [...images];
    const [movedItem] = newImages.splice(draggedIndex, 1);
    newImages.splice(targetIndex, 0, movedItem);

    onReorderImages(newImages);
    onSelectPage(targetIndex);
    setDraggedIndex(null);
    setDragOverIndex(null);
  };

  const moveImage = (index: number, direction: 'up' | 'down') => {
    const targetIndex = direction === 'up' ? index - 1 : index + 1;
    if (targetIndex < 0 || targetIndex >= images.length) return;

    const newImages = [...images];
    const [movedItem] = newImages.splice(index, 1);
    newImages.splice(targetIndex, 0, movedItem);

    onReorderImages(newImages);
    onSelectPage(targetIndex);
  };

  const sortImages = (type: 'name-asc' | 'name-desc' | 'size-asc' | 'size-desc') => {
    const sorted = [...images].sort((a, b) => {
      if (type === 'name-asc') return a.name.localeCompare(b.name, undefined, { numeric: true });
      if (type === 'name-desc') return b.name.localeCompare(a.name, undefined, { numeric: true });
      if (type === 'size-asc') return a.size - b.size;
      if (type === 'size-desc') return b.size - a.size;
      return 0;
    });
    onReorderImages(sorted);
    setSortMenuOpen(false);
  };

  const autoRotateAllLandscape = () => {
    const newImages = images.map((img) => {
      // If width > height and rotation is 0 or 180, rotate to 90
      if (img.width > img.height && (img.rotation === 0 || img.rotation === 180)) {
        return { ...img, rotation: 90 };
      }
      return img;
    });
    onReorderImages(newImages);
    setSortMenuOpen(false);
  };

  return (
    <div className="flex flex-col h-full bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl shadow-sm overflow-hidden">
      {/* Panel Header */}
      <div className="p-4 border-b border-slate-200/80 dark:border-slate-800 flex items-center justify-between gap-2 bg-slate-50/70 dark:bg-slate-950/40">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-indigo-50 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-400 flex items-center justify-center font-bold text-sm">
            <Layers className="w-4 h-4" />
          </div>
          <div>
            <h2 className="font-bold text-sm text-slate-800 dark:text-slate-200 leading-tight">
              Page Images
            </h2>
            <div className="text-xs text-slate-500 dark:text-slate-400 font-medium">
              {images.length} {images.length === 1 ? 'image' : 'images'} • {totalSizeMb} MB
            </div>
          </div>
        </div>

        {/* Action buttons */}
        <div className="flex items-center gap-1">
          {/* Auto Sort Dropdown */}
          <div className="relative">
            <button
              id="sort-menu-button"
              onClick={() => setSortMenuOpen(!sortMenuOpen)}
              title="Sort & Arrange images"
              className="p-1.5 rounded-lg text-slate-600 dark:text-slate-400 hover:bg-slate-200/60 dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-white transition-colors"
            >
              <ArrowUpDown className="w-4 h-4" />
            </button>

            {sortMenuOpen && (
              <div
                id="sort-dropdown-menu"
                className="absolute right-0 top-full mt-1.5 w-48 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl shadow-xl z-30 p-1 text-xs text-slate-700 dark:text-slate-200"
              >
                <button
                  onClick={() => sortImages('name-asc')}
                  className="w-full text-left px-3 py-2 rounded-lg hover:bg-indigo-50 dark:hover:bg-indigo-950 hover:text-indigo-600 dark:hover:text-indigo-400 flex items-center justify-between"
                >
                  <span>Sort by Name (A → Z)</span>
                </button>
                <button
                  onClick={() => sortImages('name-desc')}
                  className="w-full text-left px-3 py-2 rounded-lg hover:bg-indigo-50 dark:hover:bg-indigo-950 hover:text-indigo-600 dark:hover:text-indigo-400 flex items-center justify-between"
                >
                  <span>Sort by Name (Z → A)</span>
                </button>
                <button
                  onClick={() => sortImages('size-desc')}
                  className="w-full text-left px-3 py-2 rounded-lg hover:bg-indigo-50 dark:hover:bg-indigo-950 hover:text-indigo-600 dark:hover:text-indigo-400 flex items-center justify-between"
                >
                  <span>Sort by Size (Largest)</span>
                </button>
                <button
                  onClick={autoRotateAllLandscape}
                  className="w-full text-left px-3 py-2 rounded-lg hover:bg-indigo-50 dark:hover:bg-indigo-950 hover:text-indigo-600 dark:hover:text-indigo-400 flex items-center justify-between border-t border-slate-100 dark:border-slate-700/60 mt-1 pt-1.5"
                >
                  <span className="flex items-center gap-1.5">
                    <Compass className="w-3.5 h-3.5 text-indigo-500" />
                    Auto-orient all
                  </span>
                </button>
              </div>
            )}
          </div>

          {/* Clear All */}
          <button
            id="clear-all-images-button"
            onClick={onClearAll}
            title="Remove all images"
            className="p-1.5 rounded-lg text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/50 hover:text-rose-600 transition-colors text-xs font-semibold"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Add more images compact dropzone */}
      <div className="p-3 border-b border-slate-100 dark:border-slate-800/80">
        <Dropzone onImagesAdded={onAddImages} compact={true} />
      </div>

      {/* Thumbnails Scrollable List */}
      <div
        id="image-thumbnails-list"
        className="flex-1 overflow-y-auto p-3 space-y-2.5 max-h-[580px] min-h-[300px]"
      >
        {images.map((image, index) => {
          const isActive = index === activePageIndex;
          const isBeingDragged = draggedIndex === index;
          const isDropTarget = dragOverIndex === index;

          return (
            <div
              key={image.id}
              id={`thumbnail-card-${index}`}
              draggable
              onDragStart={(e) => handleDragStart(e, index)}
              onDragOver={(e) => handleDragOver(e, index)}
              onDrop={(e) => handleDrop(e, index)}
              onClick={() => onSelectPage(index)}
              className={`group relative rounded-xl border transition-all duration-150 p-2.5 flex items-center gap-3 cursor-pointer ${
                isActive
                  ? 'border-indigo-500 bg-indigo-50/50 dark:bg-indigo-950/40 shadow-sm ring-1 ring-indigo-500/30'
                  : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 hover:border-slate-300 dark:hover:border-slate-700'
              } ${isBeingDragged ? 'opacity-40 scale-95 border-dashed border-indigo-400' : ''} ${
                isDropTarget ? 'border-t-2 border-t-indigo-600 bg-indigo-50/60 dark:bg-indigo-950/60' : ''
              }`}
            >
              {/* Drag Handle */}
              <div
                className="text-slate-400 hover:text-slate-600 dark:text-slate-500 dark:hover:text-slate-300 cursor-grab active:cursor-grabbing p-0.5"
                title="Drag to reorder"
              >
                <GripVertical className="w-4 h-4" />
              </div>

              {/* Page Number Badge */}
              <div className="w-6 h-6 rounded-md bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-bold text-xs flex items-center justify-center shrink-0 border border-slate-200 dark:border-slate-700">
                {index + 1}
              </div>

              {/* Image Thumbnail with Rotation */}
              <div className="relative w-14 h-14 rounded-lg bg-checkered overflow-hidden shrink-0 border border-slate-200 dark:border-slate-700 flex items-center justify-center">
                <img
                  src={image.src}
                  alt={image.name}
                  className="max-w-full max-h-full object-contain transition-transform duration-200"
                  style={{
                    transform: `rotate(${image.rotation}deg)`,
                  }}
                />
                {image.rotation > 0 && (
                  <span className="absolute bottom-0.5 right-0.5 px-1 py-0.2 text-[9px] font-bold rounded bg-black/75 text-white">
                    {image.rotation}°
                  </span>
                )}
              </div>

              {/* Image Info */}
              <div className="flex-1 min-w-0">
                <p className="text-xs font-semibold text-slate-800 dark:text-slate-200 truncate leading-tight">
                  {image.name}
                </p>
                <p className="text-[11px] text-slate-400 dark:text-slate-500 mt-0.5">
                  {image.width} × {image.height}px • {(image.size / 1024).toFixed(0)} KB
                </p>
              </div>

              {/* Action Buttons */}
              <div
                className="flex items-center gap-1 opacity-90 sm:opacity-0 group-hover:opacity-100 transition-opacity"
                onClick={(e) => e.stopPropagation()}
              >
                {/* Rotate Left */}
                <button
                  onClick={() => onRotateImage(image.id, -90)}
                  title="Rotate Left 90°"
                  className="p-1 rounded-md text-slate-500 hover:text-indigo-600 dark:text-slate-400 dark:hover:text-indigo-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                </button>

                {/* Rotate Right */}
                <button
                  onClick={() => onRotateImage(image.id, 90)}
                  title="Rotate Right 90°"
                  className="p-1 rounded-md text-slate-500 hover:text-indigo-600 dark:text-slate-400 dark:hover:text-indigo-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                >
                  <RotateCw className="w-3.5 h-3.5" />
                </button>

                {/* Inspect / Preview Modal */}
                <button
                  onClick={() => onOpenPreviewModal(image)}
                  title="Preview image in detail"
                  className="p-1 rounded-md text-slate-500 hover:text-indigo-600 dark:text-slate-400 dark:hover:text-indigo-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                >
                  <Eye className="w-3.5 h-3.5" />
                </button>

                {/* Move Up / Down */}
                <div className="flex flex-col">
                  <button
                    disabled={index === 0}
                    onClick={() => moveImage(index, 'up')}
                    title="Move Page Up"
                    className="p-0.5 rounded text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 disabled:opacity-20 disabled:hover:text-slate-400"
                  >
                    <ArrowUp className="w-3 h-3" />
                  </button>
                  <button
                    disabled={index === images.length - 1}
                    onClick={() => moveImage(index, 'down')}
                    title="Move Page Down"
                    className="p-0.5 rounded text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 disabled:opacity-20 disabled:hover:text-slate-400"
                  >
                    <ArrowDown className="w-3 h-3" />
                  </button>
                </div>

                {/* Delete */}
                <button
                  onClick={() => onDeleteImage(image.id)}
                  title="Delete page"
                  className="p-1 rounded-md text-slate-400 hover:text-rose-600 dark:hover:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/50 transition-colors"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Footer hint */}
      <div className="p-2.5 bg-slate-50 dark:bg-slate-950/60 border-t border-slate-200/80 dark:border-slate-800 text-center text-[11px] text-slate-400 dark:text-slate-500">
        💡 Drag cards to reorder • Click thumbnail to inspect
      </div>
    </div>
  );
};

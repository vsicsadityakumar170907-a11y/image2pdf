import React from 'react';
import {
  Settings,
  Sliders,
  Maximize2,
  FileCheck,
  Hash,
  Palette,
  Sparkles,
  RotateCcw,
  AlignLeft,
  Minimize2,
  Type,
  FileText,
} from 'lucide-react';
import {
  PdfSettings,
  PageSize,
  PageOrientation,
  ImageFit,
  MarginsPreset,
  ImageQuality,
  PageNumberPosition,
  PageNumberFormat,
} from '../types';

interface PdfSettingsPanelProps {
  settings: PdfSettings;
  onChangeSettings: (newSettings: PdfSettings) => void;
  onResetSettings: () => void;
}

const BG_COLOR_PRESETS = [
  { name: 'White', hex: '#ffffff', class: 'bg-white border-slate-300' },
  { name: 'Warm Cream', hex: '#fdfbf7', class: 'bg-[#fdfbf7] border-amber-200' },
  { name: 'Soft Gray', hex: '#f1f5f9', class: 'bg-[#f1f5f9] border-slate-300' },
  { name: 'Slate Dark', hex: '#0f172a', class: 'bg-[#0f172a] border-slate-700' },
];

export const PdfSettingsPanel: React.FC<PdfSettingsPanelProps> = ({
  settings,
  onChangeSettings,
  onResetSettings,
}) => {
  const updateSetting = <K extends keyof PdfSettings>(key: K, value: PdfSettings[K]) => {
    onChangeSettings({
      ...settings,
      [key]: value,
    });
  };

  return (
    <div className="flex flex-col h-full bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl shadow-sm overflow-hidden">
      {/* Header */}
      <div className="p-4 border-b border-slate-200/80 dark:border-slate-800 bg-slate-50/80 dark:bg-slate-950/40 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-indigo-50 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-400 flex items-center justify-center font-bold text-sm">
            <Sliders className="w-4 h-4" />
          </div>
          <div>
            <h2 className="font-bold text-sm text-slate-800 dark:text-slate-200 leading-tight">
              PDF Settings
            </h2>
            <div className="text-xs text-slate-500 dark:text-slate-400 font-medium">
              Layout & Output Options
            </div>
          </div>
        </div>

        <button
          onClick={onResetSettings}
          title="Reset to defaults"
          className="text-xs font-semibold text-slate-500 hover:text-indigo-600 dark:text-slate-400 dark:hover:text-indigo-400 flex items-center gap-1 transition-colors"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>Reset</span>
        </button>
      </div>

      {/* Settings Scrollable Body */}
      <div className="flex-1 overflow-y-auto p-4 space-y-5 max-h-[580px]">
        {/* 1. PDF File Name */}
        <div>
          <label className="block text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-1.5">
            PDF File Name
          </label>
          <div className="relative">
            <input
              id="pdf-filename-input"
              type="text"
              value={settings.filename}
              onChange={(e) => updateSetting('filename', e.target.value)}
              placeholder="document"
              className="w-full pl-3 pr-12 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm font-semibold text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all"
            />
            <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs font-mono font-bold text-slate-400 dark:text-slate-500 pointer-events-none">
              .pdf
            </span>
          </div>
        </div>

        {/* 2. Page Size */}
        <div>
          <label className="block text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-1.5">
            Page Size
          </label>
          <div className="grid grid-cols-3 gap-1.5">
            {[
              { id: 'a4', label: 'A4', desc: '210×297mm' },
              { id: 'letter', label: 'Letter', desc: '8.5×11in' },
              { id: 'legal', label: 'Legal', desc: '8.5×14in' },
              { id: 'a3', label: 'A3', desc: '297×420mm' },
              { id: 'fit_image', label: 'Fit Image', desc: 'Exact px' },
              { id: 'custom', label: 'Custom', desc: 'Set mm' },
            ].map((size) => (
              <button
                key={size.id}
                type="button"
                id={`pagesize-${size.id}`}
                onClick={() => updateSetting('pageSize', size.id as PageSize)}
                className={`p-2 rounded-xl border text-center transition-all cursor-pointer ${
                  settings.pageSize === size.id
                    ? 'border-indigo-600 bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300 font-bold shadow-xs'
                    : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-800/60 text-slate-700 dark:text-slate-300 hover:border-slate-300 dark:hover:border-slate-700'
                }`}
              >
                <div className="text-xs font-bold">{size.label}</div>
                <div className="text-[10px] text-slate-400 dark:text-slate-500">{size.desc}</div>
              </button>
            ))}
          </div>

          {/* Custom Size inputs */}
          {settings.pageSize === 'custom' && (
            <div className="grid grid-cols-2 gap-2 mt-2 p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-700">
              <div>
                <label className="text-[11px] font-semibold text-slate-500">Width (mm)</label>
                <input
                  type="number"
                  value={settings.customWidth}
                  onChange={(e) => updateSetting('customWidth', Math.max(10, parseInt(e.target.value) || 210))}
                  className="w-full mt-1 p-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs font-semibold"
                />
              </div>
              <div>
                <label className="text-[11px] font-semibold text-slate-500">Height (mm)</label>
                <input
                  type="number"
                  value={settings.customHeight}
                  onChange={(e) => updateSetting('customHeight', Math.max(10, parseInt(e.target.value) || 297))}
                  className="w-full mt-1 p-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs font-semibold"
                />
              </div>
            </div>
          )}
        </div>

        {/* 3. Orientation */}
        <div>
          <label className="block text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-1.5">
            Orientation
          </label>
          <div className="grid grid-cols-3 gap-1.5">
            {[
              { id: 'portrait', label: 'Portrait', icon: '📄' },
              { id: 'landscape', label: 'Landscape', icon: '📃' },
              { id: 'auto', label: 'Auto (Per-img)', icon: '✨' },
            ].map((orient) => (
              <button
                key={orient.id}
                type="button"
                id={`orientation-${orient.id}`}
                onClick={() => updateSetting('orientation', orient.id as PageOrientation)}
                className={`py-2 px-2 rounded-xl border text-xs font-semibold transition-all flex items-center justify-center gap-1.5 ${
                  settings.orientation === orient.id
                    ? 'border-indigo-600 bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300 font-bold shadow-xs'
                    : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-800/60 text-slate-700 dark:text-slate-300 hover:border-slate-300'
                }`}
              >
                <span>{orient.icon}</span>
                <span>{orient.label}</span>
              </button>
            ))}
          </div>
        </div>

        {/* 4. Image Fit */}
        <div>
          <label className="block text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-1.5">
            Image Fit to Page
          </label>
          <div className="grid grid-cols-2 gap-1.5">
            {[
              { id: 'contain', label: 'Fit to Page', desc: 'Contain with ratio' },
              { id: 'cover', label: 'Fill Page', desc: 'Bleed / Cover full' },
              { id: 'original', label: 'Original Size', desc: '100% native scale' },
              { id: 'stretch', label: 'Stretch', desc: 'Match dimensions' },
            ].map((fit) => (
              <button
                key={fit.id}
                type="button"
                id={`fit-${fit.id}`}
                onClick={() => updateSetting('imageFit', fit.id as ImageFit)}
                className={`p-2 rounded-xl border text-left transition-all ${
                  settings.imageFit === fit.id
                    ? 'border-indigo-600 bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300 font-bold shadow-xs'
                    : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-800/60 text-slate-700 dark:text-slate-300 hover:border-slate-300'
                }`}
              >
                <div className="text-xs font-bold">{fit.label}</div>
                <div className="text-[10px] text-slate-400 dark:text-slate-500">{fit.desc}</div>
              </button>
            ))}
          </div>
        </div>

        {/* 5. Margins */}
        <div>
          <label className="block text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-1.5">
            Margins
          </label>
          <div className="grid grid-cols-4 gap-1.5">
            {[
              { id: 'none', label: 'None', mm: '0mm' },
              { id: 'small', label: 'Small', mm: '5mm' },
              { id: 'medium', label: 'Med', mm: '10mm' },
              { id: 'large', label: 'Large', mm: '20mm' },
            ].map((m) => (
              <button
                key={m.id}
                type="button"
                id={`margin-${m.id}`}
                onClick={() => updateSetting('margins', m.id as MarginsPreset)}
                className={`py-2 px-1 rounded-xl border text-center transition-all ${
                  settings.margins === m.id
                    ? 'border-indigo-600 bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300 font-bold shadow-xs'
                    : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-800/60 text-slate-700 dark:text-slate-300 hover:border-slate-300'
                }`}
              >
                <div className="text-xs font-bold">{m.label}</div>
                <div className="text-[10px] text-slate-400 dark:text-slate-500">{m.mm}</div>
              </button>
            ))}
          </div>
        </div>

        {/* 6. Image Quality & Compression */}
        <div>
          <label className="block text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-1.5">
            Image Quality / Compression
          </label>
          <div className="grid grid-cols-3 gap-1.5">
            {[
              { id: 'high', label: 'High (95%)', desc: 'Best clarity' },
              { id: 'medium', label: 'Medium (80%)', desc: 'Balanced' },
              { id: 'low', label: 'Low (60%)', desc: 'Small file size' },
            ].map((q) => (
              <button
                key={q.id}
                type="button"
                id={`quality-${q.id}`}
                onClick={() => updateSetting('quality', q.id as ImageQuality)}
                className={`p-2 rounded-xl border text-center transition-all ${
                  settings.quality === q.id
                    ? 'border-indigo-600 bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300 font-bold shadow-xs'
                    : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-800/60 text-slate-700 dark:text-slate-300 hover:border-slate-300'
                }`}
              >
                <div className="text-xs font-bold">{q.label}</div>
                <div className="text-[10px] text-slate-400 dark:text-slate-500">{q.desc}</div>
              </button>
            ))}
          </div>
        </div>

        {/* 7. Background Color */}
        <div>
          <label className="block text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-1.5">
            Background Color
          </label>
          <div className="flex items-center gap-2">
            {BG_COLOR_PRESETS.map((color) => (
              <button
                key={color.hex}
                type="button"
                onClick={() => updateSetting('backgroundColor', color.hex)}
                className={`w-7 h-7 rounded-full border-2 transition-all cursor-pointer ${color.class} ${
                  settings.backgroundColor.toLowerCase() === color.hex.toLowerCase()
                    ? 'ring-2 ring-indigo-500 ring-offset-2 scale-110'
                    : 'hover:scale-105'
                }`}
                title={color.name}
              />
            ))}
            {/* Custom Color Input */}
            <div className="flex items-center gap-1.5 ml-auto">
              <input
                type="color"
                value={settings.backgroundColor}
                onChange={(e) => updateSetting('backgroundColor', e.target.value)}
                className="w-7 h-7 rounded-lg border border-slate-300 dark:border-slate-700 cursor-pointer p-0 bg-transparent"
                title="Choose custom color"
              />
              <span className="text-xs font-mono text-slate-500 dark:text-slate-400">
                {settings.backgroundColor.toUpperCase()}
              </span>
            </div>
          </div>
        </div>

        {/* 8. Page Numbering */}
        <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Hash className="w-4 h-4 text-indigo-500" />
              <span className="text-xs font-bold text-slate-700 dark:text-slate-200">
                Page Numbering
              </span>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                id="page-numbering-toggle"
                checked={settings.pageNumbers}
                onChange={(e) => updateSetting('pageNumbers', e.target.checked)}
                className="sr-only peer"
              />
              <div className="w-9 h-5 bg-slate-300 peer-focus:outline-none rounded-full peer dark:bg-slate-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-indigo-600"></div>
            </label>
          </div>

          {settings.pageNumbers && (
            <div className="mt-3 pt-3 border-t border-slate-200/80 dark:border-slate-700/60 space-y-2.5">
              <div>
                <label className="text-[11px] font-semibold text-slate-500">Format</label>
                <select
                  value={settings.pageNumberFormat}
                  onChange={(e) => updateSetting('pageNumberFormat', e.target.value as PageNumberFormat)}
                  className="w-full mt-1 p-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs font-medium"
                >
                  <option value="page_of_total">Page X of Y</option>
                  <option value="simple">X / Y</option>
                  <option value="page_only">X (Number only)</option>
                </select>
              </div>

              <div>
                <label className="text-[11px] font-semibold text-slate-500">Position</label>
                <select
                  value={settings.pageNumberPosition}
                  onChange={(e) => updateSetting('pageNumberPosition', e.target.value as PageNumberPosition)}
                  className="w-full mt-1 p-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs font-medium"
                >
                  <option value="bottom-center">Bottom Center</option>
                  <option value="bottom-right">Bottom Right</option>
                  <option value="bottom-left">Bottom Left</option>
                  <option value="top-right">Top Right</option>
                </select>
              </div>
            </div>
          )}
        </div>

        {/* 9. Header & Footer Text (Optional) */}
        <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800 space-y-2">
          <div className="flex items-center gap-1.5 text-xs font-bold text-slate-700 dark:text-slate-200">
            <Type className="w-3.5 h-3.5 text-indigo-500" />
            <span>Document Notes (Header / Footer)</span>
          </div>
          <div>
            <input
              type="text"
              placeholder="Header title (optional)"
              value={settings.headerText}
              onChange={(e) => updateSetting('headerText', e.target.value)}
              className="w-full p-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs text-slate-700 dark:text-slate-200"
            />
          </div>
          <div>
            <input
              type="text"
              placeholder="Footer text / watermark (optional)"
              value={settings.footerText}
              onChange={(e) => updateSetting('footerText', e.target.value)}
              className="w-full p-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs text-slate-700 dark:text-slate-200"
            />
          </div>
        </div>
      </div>
    </div>
  );
};

import React from 'react';
import { ShieldCheck, Lock, EyeOff, Trash2, Cpu } from 'lucide-react';

export const PrivacyBanner: React.FC = () => {
  return (
    <section id="privacy" className="py-16 md:py-20 border-t border-slate-200/80 dark:border-slate-800/80 bg-gradient-to-b from-indigo-50/50 to-white dark:from-indigo-950/20 dark:to-slate-900">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="rounded-3xl border border-indigo-200 dark:border-indigo-800/80 bg-white/80 dark:bg-slate-900/80 backdrop-blur-md p-8 sm:p-12 shadow-sm">
          <div className="flex flex-col md:flex-row items-start md:items-center gap-6 justify-between mb-8">
            <div className="flex items-center gap-4">
              <div className="w-14 h-14 rounded-2xl bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20 flex items-center justify-center shrink-0">
                <ShieldCheck className="w-8 h-8" />
              </div>
              <div>
                <h3 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight">
                  Your images stay 100% private.
                </h3>
                <p className="text-sm sm:text-base text-slate-600 dark:text-slate-400 mt-1">
                  We believe your personal documents and private photos belong only to you.
                </p>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 pt-6 border-t border-slate-200/80 dark:border-slate-800">
            <div className="flex items-start gap-3">
              <Cpu className="w-5 h-5 text-indigo-500 shrink-0 mt-0.5" />
              <div>
                <h4 className="text-sm font-bold text-slate-800 dark:text-slate-200">Local Browser Execution</h4>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                  All rendering occurs client-side using JavaScript canvas and WebAssembly.
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <EyeOff className="w-5 h-5 text-indigo-500 shrink-0 mt-0.5" />
              <div>
                <h4 className="text-sm font-bold text-slate-800 dark:text-slate-200">Zero Server Storage</h4>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                  Files are never transmitted over the internet or written to remote disks.
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <Trash2 className="w-5 h-5 text-indigo-500 shrink-0 mt-0.5" />
              <div>
                <h4 className="text-sm font-bold text-slate-800 dark:text-slate-200">Automatic Memory Cleanup</h4>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                  Memory blobs are cleared as soon as your session ends or you leave the converter.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

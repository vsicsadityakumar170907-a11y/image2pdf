import React from 'react';
import { Upload, Shuffle, SlidersHorizontal, Download, ArrowRight } from 'lucide-react';

export const HowItWorksSection: React.FC = () => {
  const steps = [
    {
      num: '01',
      icon: Upload,
      title: 'Upload Your Images',
      desc: 'Select or drag & drop multiple JPG, PNG, WEBP, or SVG files directly into the converter.',
    },
    {
      num: '02',
      icon: Shuffle,
      title: 'Organize & Rotate',
      desc: 'Drag thumbnails to rearrange page order. Rotate any sideways or upside-down images with a single click.',
    },
    {
      num: '03',
      icon: SlidersHorizontal,
      title: 'Customize Layout',
      desc: 'Pick your paper size (A4, Letter, Legal), orientation, margins, background colors, and page numbers.',
    },
    {
      num: '04',
      icon: Download,
      title: 'Download PDF',
      desc: 'Click "Create PDF" to compile your document instantly in-browser and save your crisp PDF file.',
    },
  ];

  return (
    <section id="how-it-works" className="py-16 md:py-24 border-t border-slate-200/80 dark:border-slate-800/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-14">
          <div className="text-xs font-bold uppercase tracking-wider text-indigo-600 dark:text-indigo-400 mb-2">
            Simple 4-Step Process
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-slate-900 dark:text-white">
            How Image2PDF Works
          </h2>
          <p className="text-slate-600 dark:text-slate-400 mt-3 text-base sm:text-lg">
            No registration, no installation, and no subscription fees. Just pure speed.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 relative">
          {steps.map((step, idx) => {
            const Icon = step.icon;
            return (
              <div
                key={idx}
                className="relative p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <span className="text-2xl font-black text-indigo-600/30 dark:text-indigo-400/30 font-mono">
                      {step.num}
                    </span>
                    <div className="w-10 h-10 rounded-xl bg-indigo-50 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-400 flex items-center justify-center">
                      <Icon className="w-5 h-5" />
                    </div>
                  </div>
                  <h3 className="text-base font-bold text-slate-900 dark:text-white mb-2">
                    {step.title}
                  </h3>
                  <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 leading-relaxed">
                    {step.desc}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};

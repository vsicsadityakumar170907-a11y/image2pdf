import React from 'react';
import { Upload, Sparkles, ArrowRight, ShieldCheck, Zap, Layers, Sliders, FileDown } from 'lucide-react';

interface HeroSectionProps {
  onTriggerUpload: () => void;
  onTryDemo: () => void;
  isLoadingDemo?: boolean;
}

export const HeroSection: React.FC<HeroSectionProps> = ({
  onTriggerUpload,
  onTryDemo,
  isLoadingDemo = false,
}) => {
  return (
    <section id="hero" className="relative overflow-hidden pt-8 pb-12 md:pt-14 md:pb-16">
      {/* Subtle ambient lighting */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[600px] h-[300px] bg-indigo-500/10 dark:bg-indigo-500/20 blur-[100px] rounded-full pointer-events-none -z-10" />

      <div className="max-w-4xl mx-auto px-4 sm:px-6 text-center">
        {/* Privacy Pill */}
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full text-xs font-semibold bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300 border border-indigo-200/80 dark:border-indigo-800/80 mb-6 shadow-sm">
          <ShieldCheck className="w-4 h-4 text-emerald-500 dark:text-emerald-400" />
          <span>100% Client-Side • Your Images Never Leave Your Browser</span>
        </div>

        {/* Hero Title */}
        <h1 className="text-4xl sm:text-5xl md:text-6xl font-extrabold tracking-tight text-slate-900 dark:text-white leading-[1.15] mb-6">
          Convert Images to PDF in{' '}
          <span className="bg-gradient-to-r from-indigo-600 via-indigo-500 to-violet-600 bg-clip-text text-transparent">
            Seconds
          </span>
        </h1>

        {/* Subtitle */}
        <p className="text-lg sm:text-xl text-slate-600 dark:text-slate-300 max-w-2xl mx-auto font-normal leading-relaxed mb-8">
          Upload your images, arrange them, customize your document, and download a professional PDF — completely from your browser.
        </p>

        {/* CTA Buttons */}
        <div className="flex flex-wrap items-center justify-center gap-3.5 mb-12">
          <button
            id="hero-upload-button"
            onClick={onTriggerUpload}
            className="px-6 py-3.5 rounded-xl font-semibold text-white bg-indigo-600 hover:bg-indigo-500 active:bg-indigo-700 shadow-lg shadow-indigo-600/30 hover:shadow-indigo-600/40 hover:-translate-y-0.5 active:translate-y-0 transition-all flex items-center gap-2.5 text-base"
          >
            <Upload className="w-5 h-5" />
            <span>Upload Images</span>
          </button>

          <button
            id="hero-demo-button"
            onClick={onTryDemo}
            disabled={isLoadingDemo}
            className="px-6 py-3.5 rounded-xl font-semibold text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800/90 border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 active:bg-slate-100 shadow-sm hover:-translate-y-0.5 active:translate-y-0 transition-all flex items-center gap-2 text-base disabled:opacity-60"
          >
            <Sparkles className="w-4 h-4 text-amber-500 animate-spin-slow" />
            <span>{isLoadingDemo ? 'Loading Demo...' : 'Try Demo with Samples'}</span>
          </button>
        </div>

        {/* Visual Process Flow Ribbon */}
        <div className="bg-white/60 dark:bg-slate-900/60 backdrop-blur-sm border border-slate-200/80 dark:border-slate-800/80 rounded-2xl p-4 sm:p-5 shadow-sm max-w-3xl mx-auto">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 sm:gap-2 text-left">
            {/* Step 1 */}
            <div className="flex items-center gap-3 p-2 rounded-xl">
              <div className="w-9 h-9 rounded-lg bg-indigo-50 dark:bg-indigo-950/70 border border-indigo-200 dark:border-indigo-800 flex items-center justify-center text-indigo-600 dark:text-indigo-400 font-bold shrink-0">
                <Upload className="w-4 h-4" />
              </div>
              <div>
                <div className="text-xs font-bold uppercase tracking-wider text-slate-400 dark:text-slate-500">Step 1</div>
                <div className="text-sm font-semibold text-slate-800 dark:text-slate-200">Upload Images</div>
              </div>
            </div>

            {/* Step 2 */}
            <div className="flex items-center gap-3 p-2 rounded-xl">
              <div className="w-9 h-9 rounded-lg bg-violet-50 dark:bg-violet-950/70 border border-violet-200 dark:border-violet-800 flex items-center justify-center text-violet-600 dark:text-violet-400 font-bold shrink-0">
                <Layers className="w-4 h-4" />
              </div>
              <div>
                <div className="text-xs font-bold uppercase tracking-wider text-slate-400 dark:text-slate-500">Step 2</div>
                <div className="text-sm font-semibold text-slate-800 dark:text-slate-200">Arrange & Rotate</div>
              </div>
            </div>

            {/* Step 3 */}
            <div className="flex items-center gap-3 p-2 rounded-xl">
              <div className="w-9 h-9 rounded-lg bg-blue-50 dark:bg-blue-950/70 border border-blue-200 dark:border-blue-800 flex items-center justify-center text-blue-600 dark:text-blue-400 font-bold shrink-0">
                <Sliders className="w-4 h-4" />
              </div>
              <div>
                <div className="text-xs font-bold uppercase tracking-wider text-slate-400 dark:text-slate-500">Step 3</div>
                <div className="text-sm font-semibold text-slate-800 dark:text-slate-200">Customize PDF</div>
              </div>
            </div>

            {/* Step 4 */}
            <div className="flex items-center gap-3 p-2 rounded-xl">
              <div className="w-9 h-9 rounded-lg bg-emerald-50 dark:bg-emerald-950/70 border border-emerald-200 dark:border-emerald-800 flex items-center justify-center text-emerald-600 dark:text-emerald-400 font-bold shrink-0">
                <FileDown className="w-4 h-4" />
              </div>
              <div>
                <div className="text-xs font-bold uppercase tracking-wider text-slate-400 dark:text-slate-500">Step 4</div>
                <div className="text-sm font-semibold text-slate-800 dark:text-slate-200">Download PDF</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

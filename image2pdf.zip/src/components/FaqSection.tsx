import React, { useState } from 'react';
import { ChevronDown, HelpCircle } from 'lucide-react';

export const FaqSection: React.FC = () => {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const faqs = [
    {
      q: 'Which image file formats are supported?',
      a: 'Image2PDF supports all standard web raster and vector image formats: JPG, JPEG, PNG, WEBP, GIF, and SVG. You can mix and match different formats in a single PDF.',
    },
    {
      q: 'Is there a limit on how many images I can convert?',
      a: 'No artificial limits! You can convert 2 images or 200+ images into a single PDF document. Because processing takes place directly in your browser, the only boundary is your computer’s available RAM.',
    },
    {
      q: 'Are my images uploaded to any server?',
      a: 'Never. Image2PDF operates entirely client-side using JavaScript and the jsPDF engine. Your files never leave your computer or device.',
    },
    {
      q: 'Can I change page orientation or mix portrait and landscape?',
      a: 'Yes! You can choose strict Portrait, strict Landscape, or the intelligent "Auto (Per-image)" mode, which automatically matches each page orientation to that specific image’s aspect ratio.',
    },
    {
      q: 'How do I reorder images before downloading?',
      a: 'Simply drag and drop the thumbnails in the left panel, or use the quick "Move Up" / "Move Down" arrow buttons. You can also auto-sort by name or file size.',
    },
    {
      q: 'Can I compress images to make the PDF file smaller?',
      a: 'Yes, under PDF Settings > Image Quality, you can select Medium (80%) or Low (60%) to dramatically reduce the file size of the generated PDF without noticeable loss in document readability.',
    },
  ];

  return (
    <section id="faq" className="py-16 md:py-24 border-t border-slate-200/80 dark:border-slate-800/80">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-950/60 border border-indigo-200 dark:border-indigo-800 mb-3">
            <HelpCircle className="w-3.5 h-3.5" />
            <span>Got Questions?</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-slate-900 dark:text-white">
            Frequently Asked Questions
          </h2>
          <p className="text-slate-600 dark:text-slate-400 mt-2 text-base">
            Everything you need to know about converting images to PDF online.
          </p>
        </div>

        <div className="space-y-3">
          {faqs.map((faq, idx) => {
            const isOpen = openIndex === idx;
            return (
              <div
                key={idx}
                className="rounded-2xl border border-slate-200/80 dark:border-slate-800 bg-white dark:bg-slate-900 overflow-hidden transition-colors"
              >
                <button
                  onClick={() => setOpenIndex(isOpen ? null : idx)}
                  className="w-full p-5 text-left flex items-center justify-between gap-4 cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-800/40 transition-colors"
                >
                  <span className="font-bold text-sm sm:text-base text-slate-900 dark:text-slate-100">
                    {faq.q}
                  </span>
                  <ChevronDown
                    className={`w-5 h-5 text-slate-400 transition-transform duration-200 shrink-0 ${
                      isOpen ? 'rotate-180 text-indigo-600 dark:text-indigo-400' : ''
                    }`}
                  />
                </button>

                {isOpen && (
                  <div className="px-5 pb-5 pt-1 text-xs sm:text-sm text-slate-600 dark:text-slate-400 leading-relaxed border-t border-slate-100 dark:border-slate-800/60">
                    {faq.a}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
